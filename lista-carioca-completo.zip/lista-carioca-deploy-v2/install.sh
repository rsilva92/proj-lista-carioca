#!/usr/bin/env bash
# =============================================================================
#
#   ██╗     ██╗███████╗████████╗ █████╗      ██████╗ █████╗ ██████╗ ██╗ ██████╗  ██████╗ █████╗
#   ██║     ██║██╔════╝╚══██╔══╝██╔══██╗    ██╔════╝██╔══██╗██╔══██╗██║██╔═══██╗██╔════╝██╔══██╗
#   ██║     ██║███████╗   ██║   ███████║    ██║     ███████║██████╔╝██║██║   ██║██║     ███████║
#   ██║     ██║╚════██║   ██║   ██╔══██║    ██║     ██╔══██║██╔══██╗██║██║   ██║██║     ██╔══██║
#   ███████╗██║███████║   ██║   ██║  ██║    ╚██████╗██║  ██║██║  ██║██║╚██████╔╝╚██████╗██║  ██║
#   ╚══════╝╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝     ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝
#
#   Marketplace de Serviços de Beleza — Cabo Frio, RJ
#   Script de Instalação Completa v2.0
#   PHP Puro + MySQL + Apache2 (sem frameworks)
#
#   Uso:
#     sudo bash install.sh
#     sudo APP_DOMAIN=meusite.com.br bash install.sh
#
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# =============================================================================
#  CONFIGURAÇÕES — edite estas variáveis antes de executar
# =============================================================================
APP_DOMAIN="${APP_DOMAIN:-lista-carioca.local}"
APP_DIR="${APP_DIR:-/var/www/lista-carioca}"
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-3306}"
DB_NAME="${DB_NAME:-lista_carioca}"
DB_USER="${DB_USER:-listacarioca}"
DB_PASS="${DB_PASS:-$(openssl rand -base64 18 | tr -dc 'a-zA-Z0-9' | head -c 20)}"
MYSQL_ROOT_PASS="${MYSQL_ROOT_PASS:-}"   # senha do root MySQL (vazio = sem senha)
PHP_VERSION="${PHP_VERSION:-8.2}"
APP_ENV="${APP_ENV:-production}"         # production | development

# =============================================================================
#  CORES E HELPERS
# =============================================================================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

step=0
total_steps=12

log_header() { echo -e "\n${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; echo -e "${CYAN}${BOLD}  [$((++step))/$total_steps] $1${NC}"; echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"; }
log_ok()     { echo -e "  ${GREEN}✔${NC}  $1"; }
log_info()   { echo -e "  ${BLUE}→${NC}  $1"; }
log_warn()   { echo -e "  ${YELLOW}⚠${NC}  $1"; }
log_error()  { echo -e "\n  ${RED}✘  ERRO: $1${NC}\n"; exit 1; }
log_sub()    { echo -e "     ${BLUE}·${NC} $1"; }

mysql_run() {
    if [[ -n "$MYSQL_ROOT_PASS" ]]; then
        mysql -u root -p"${MYSQL_ROOT_PASS}" -e "$1" 2>/dev/null
    else
        mysql -u root -e "$1" 2>/dev/null
    fi
}

# =============================================================================
#  BANNER
# =============================================================================
clear
echo -e "${YELLOW}${BOLD}"
cat << 'BANNER'
  ██╗     ██╗███████╗████████╗ █████╗      ██████╗ █████╗ ██████╗ ██╗ ██████╗  ██████╗ █████╗
  ██║     ██║██╔════╝╚══██╔══╝██╔══██╗    ██╔════╝██╔══██╗██╔══██╗██║██╔═══██╗██╔════╝██╔══██╗
  ██║     ██║███████╗   ██║   ███████║    ██║     ███████║██████╔╝██║██║   ██║██║     ███████║
  ██║     ██║╚════██║   ██║   ██╔══██║    ██║     ██╔══██║██╔══██╗██║██║   ██║██║     ██╔══██║
  ███████╗██║███████║   ██║   ██║  ██║    ╚██████╗██║  ██║██║  ██║██║╚██████╔╝╚██████╗██║  ██║
  ╚══════╝╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝     ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝
BANNER
echo -e "${NC}"
echo -e "  ${BOLD}Marketplace de Beleza — Cabo Frio, RJ${NC}"
echo -e "  ${CYAN}Script de Instalação Completa v2.0 — PHP Puro + MySQL + Apache2${NC}"
echo ""

# =============================================================================
#  PRÉ-CHECAGENS
# =============================================================================

# Root?
[[ $EUID -ne 0 ]] && log_error "Execute como root: sudo bash install.sh"

# apt-get disponível?
command -v apt-get &>/dev/null || log_error "Este script requer um sistema baseado em Debian/Ubuntu."

# ZIP do projeto presente?
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ZIP_FILE="${SCRIPT_DIR}/lista-carioca-web.zip"
[[ ! -f "$ZIP_FILE" ]] && log_error "Arquivo lista-carioca-web.zip não encontrado em: $SCRIPT_DIR\nColoque install.sh e lista-carioca-web.zip na mesma pasta."

# Mostrar configurações
echo -e "${BOLD}  Configurações da instalação:${NC}"
echo -e "  ┌─────────────────────────────────────────────────┐"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "Diretório:"   "$APP_DIR"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "Domínio:"     "$APP_DOMAIN"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "PHP versão:"  "$PHP_VERSION"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "Banco:"       "$DB_NAME"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "Usuário DB:"  "$DB_USER"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "Senha DB:"    "$DB_PASS"
printf  "  │  %-18s  ${YELLOW}%-26s${NC}  │\n" "Ambiente:"    "$APP_ENV"
echo -e "  └─────────────────────────────────────────────────┘"
echo ""
read -rp "  $(echo -e ${BOLD}Confirmar instalação? [s/N]:${NC}) " CONFIRM
[[ "${CONFIRM,,}" != "s" ]] && echo -e "\n  Instalação cancelada." && exit 0
echo ""

# =============================================================================
#  1. ATUALIZAR SISTEMA
# =============================================================================
log_header "Atualizando sistema"

log_info "Atualizando lista de pacotes..."
apt-get update -qq
log_info "Atualizando pacotes instalados..."
DEBIAN_FRONTEND=noninteractive apt-get upgrade -y -qq
log_ok "Sistema atualizado"

# Pacotes base
log_info "Instalando pacotes essenciais..."
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    curl wget git unzip zip openssl gnupg \
    software-properties-common apt-transport-https ca-certificates lsb-release
log_ok "Pacotes base instalados"

# =============================================================================
#  2. INSTALAR PHP
# =============================================================================
log_header "Instalando PHP ${PHP_VERSION}"

# Adicionar repositório Ondrej PPA
if ! grep -rq "ondrej/php" /etc/apt/sources.list.d/ 2>/dev/null; then
    log_info "Adicionando repositório PHP (Ondrej PPA)..."
    LC_ALL=C.UTF-8 add-apt-repository ppa:ondrej/php -y -q
    apt-get update -qq
    log_ok "Repositório adicionado"
fi

log_info "Instalando PHP ${PHP_VERSION} e extensões..."
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    php${PHP_VERSION} \
    php${PHP_VERSION}-cli \
    php${PHP_VERSION}-common \
    php${PHP_VERSION}-mysql \
    php${PHP_VERSION}-pdo \
    php${PHP_VERSION}-mbstring \
    php${PHP_VERSION}-xml \
    php${PHP_VERSION}-curl \
    php${PHP_VERSION}-zip \
    php${PHP_VERSION}-intl \
    php${PHP_VERSION}-bcmath \
    php${PHP_VERSION}-opcache \
    php${PHP_VERSION}-gd \
    libapache2-mod-php${PHP_VERSION}

# Definir versão padrão
update-alternatives --set php "/usr/bin/php${PHP_VERSION}" 2>/dev/null || true

PHP_VER_REAL=$(php -r "echo PHP_VERSION;" 2>/dev/null || echo "?")
log_ok "PHP instalado: v${PHP_VER_REAL}"

# Verificar extensões críticas
for EXT in pdo pdo_mysql mbstring; do
    if php -m 2>/dev/null | grep -q "$EXT"; then
        log_sub "Extensão ${EXT}: OK"
    else
        log_warn "Extensão ${EXT} não encontrada — verifique manualmente"
    fi
done

# =============================================================================
#  3. INSTALAR APACHE2
# =============================================================================
log_header "Instalando Apache2"

DEBIAN_FRONTEND=noninteractive apt-get install -y -qq apache2
log_ok "Apache2 instalado"

log_info "Habilitando módulos necessários..."
for MOD in rewrite headers ssl deflate expires php${PHP_VERSION}; do
    a2enmod "$MOD" 2>/dev/null && log_sub "mod_${MOD}: ativado" || log_sub "mod_${MOD}: já ativo"
done

systemctl enable apache2 --quiet
systemctl start  apache2
log_ok "Apache2 em execução"

# =============================================================================
#  4. INSTALAR MYSQL
# =============================================================================
log_header "Instalando MySQL"

DEBIAN_FRONTEND=noninteractive apt-get install -y -qq mysql-server mysql-client
systemctl enable mysql --quiet
systemctl start  mysql
log_ok "MySQL instalado e em execução"

# =============================================================================
#  5. CONFIGURAR BANCO DE DADOS
# =============================================================================
log_header "Configurando banco de dados"

log_info "Criando banco '${DB_NAME}'..."
mysql_run "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
log_ok "Banco criado"

log_info "Criando usuário '${DB_USER}'..."
mysql_run "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mysql_run "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';"
mysql_run "FLUSH PRIVILEGES;"
log_ok "Usuário criado com permissões"

# =============================================================================
#  6. INSTALAR APLICAÇÃO
# =============================================================================
log_header "Instalando a aplicação"

log_info "Extraindo lista-carioca-web.zip..."
rm -rf "${APP_DIR}"
mkdir -p "${APP_DIR}"

# Extrair zip
TMP_DIR=$(mktemp -d)
unzip -q "$ZIP_FILE" -d "$TMP_DIR"

# Encontrar pasta raiz dentro do zip (pode ser lc/ ou lista-carioca/)
ROOT_IN_ZIP=$(find "$TMP_DIR" -maxdepth 2 -name "index.php" | head -1 | xargs dirname 2>/dev/null | sed "s|/public||")
if [[ -z "$ROOT_IN_ZIP" ]]; then
    # Tentar pegar qualquer pasta de primeiro nível
    ROOT_IN_ZIP=$(find "$TMP_DIR" -maxdepth 1 -mindepth 1 -type d | head -1)
fi

if [[ -z "$ROOT_IN_ZIP" || ! -d "$ROOT_IN_ZIP" ]]; then
    log_error "Não foi possível localizar a pasta raiz dentro do ZIP."
fi

log_sub "Pasta raiz encontrada: $ROOT_IN_ZIP"
cp -r "${ROOT_IN_ZIP}/." "${APP_DIR}/"
rm -rf "$TMP_DIR"
log_ok "Arquivos copiados para ${APP_DIR}"

# Verificar estrutura mínima
for CHECK in public/index.php public/.htaccess src/config/database.php database/schema.sql; do
    if [[ -f "${APP_DIR}/${CHECK}" ]]; then
        log_sub "✔ ${CHECK}"
    else
        log_warn "Arquivo não encontrado: ${CHECK}"
    fi
done

# =============================================================================
#  7. CONFIGURAR VARIÁVEIS DA APLICAÇÃO
# =============================================================================
log_header "Configurando a aplicação"

DB_CONFIG="${APP_DIR}/src/config/database.php"

log_info "Atualizando src/config/database.php..."
cat > "$DB_CONFIG" << PHPCONF
<?php
// Gerado automaticamente pelo install.sh em $(date)
define('DB_HOST',    '${DB_HOST}');
define('DB_PORT',    '${DB_PORT}');
define('DB_NAME',    '${DB_NAME}');
define('DB_USER',    '${DB_USER}');
define('DB_PASS',    '${DB_PASS}');
define('DB_CHARSET', 'utf8mb4');

function db(): PDO {
    static \$pdo = null;
    if (\$pdo === null) {
        \$dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
        \$pdo = new PDO(\$dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return \$pdo;
}
PHPCONF
log_ok "Credenciais do banco configuradas"

# Configurar APP_ENV e APP_URL em app.php se existir
APP_CONFIG="${APP_DIR}/src/config/app.php"
if [[ -f "$APP_CONFIG" ]]; then
    sed -i "s|define('APP_ENV'.*|define('APP_ENV', '${APP_ENV}');|" "$APP_CONFIG" 2>/dev/null || true
    sed -i "s|define('APP_URL'.*|define('APP_URL', 'http://${APP_DOMAIN}');|" "$APP_CONFIG" 2>/dev/null || true
    log_ok "app.php configurado (APP_ENV=${APP_ENV}, APP_URL=http://${APP_DOMAIN})"
fi

# Desativar display_errors em produção
if [[ "$APP_ENV" == "production" ]]; then
    PHP_INI_APACHE="/etc/php/${PHP_VERSION}/apache2/php.ini"
    if [[ -f "$PHP_INI_APACHE" ]]; then
        sed -i "s/^display_errors = .*/display_errors = Off/" "$PHP_INI_APACHE"
        log_sub "display_errors desativado em produção"
    fi
fi

# =============================================================================
#  8. POPULAR BANCO DE DADOS
# =============================================================================
log_header "Importando schema e dados de teste"

SCHEMA_FILE="${APP_DIR}/database/schema.sql"
if [[ ! -f "$SCHEMA_FILE" ]]; then
    log_error "Arquivo schema.sql não encontrado em ${SCHEMA_FILE}"
fi

log_info "Importando schema.sql..."
if [[ -n "$MYSQL_ROOT_PASS" ]]; then
    mysql -u root -p"${MYSQL_ROOT_PASS}" "${DB_NAME}" < "$SCHEMA_FILE" 2>/dev/null
else
    mysql -u root "${DB_NAME}" < "$SCHEMA_FILE" 2>/dev/null
fi

# Verificar tabelas
TABLES=$(mysql_run "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${DB_NAME}';" 2>/dev/null | tail -1)
log_ok "${TABLES:-0} tabelas importadas"

# Verificar dados
USERS=$(mysql_run "SELECT COUNT(*) FROM ${DB_NAME}.users;" 2>/dev/null | tail -1)
SERVICES=$(mysql_run "SELECT COUNT(*) FROM ${DB_NAME}.services;" 2>/dev/null | tail -1)
log_sub "Usuários de teste: ${USERS:-0}"
log_sub "Serviços de teste: ${SERVICES:-0}"

# =============================================================================
#  9. PERMISSÕES DE ARQUIVOS
# =============================================================================
log_header "Configurando permissões"

log_info "Definindo proprietário (www-data)..."
chown -R www-data:www-data "${APP_DIR}"

log_info "Configurando permissões de diretórios e arquivos..."
find "${APP_DIR}" -type d -exec chmod 755 {} \;
find "${APP_DIR}" -type f -exec chmod 644 {} \;

# Proteger config com credenciais do banco
chmod 640 "${APP_DIR}/src/config/database.php"

# Tornar install.sh não acessível via web (se tiver ficado na pasta)
[[ -f "${APP_DIR}/install.sh" ]] && chmod 000 "${APP_DIR}/install.sh"

log_ok "Permissões configuradas"

# =============================================================================
#  10. CONFIGURAR VIRTUAL HOST DO APACHE
# =============================================================================
log_header "Configurando Virtual Host Apache"

VHOST_FILE="/etc/apache2/sites-available/lista-carioca.conf"

log_info "Criando ${VHOST_FILE}..."
cat > "$VHOST_FILE" << VHOST
# Lista Carioca — Virtual Host
# Gerado por install.sh em $(date)

<VirtualHost *:80>
    ServerName   ${APP_DOMAIN}
    ServerAlias  www.${APP_DOMAIN}
    DocumentRoot ${APP_DIR}/public

    <Directory ${APP_DIR}/public>
        Options       -Indexes +FollowSymLinks
        AllowOverride All
        Require       all granted

        # Segurança
        <IfModule mod_headers.c>
            Header always set X-Content-Type-Options "nosniff"
            Header always set X-Frame-Options        "SAMEORIGIN"
            Header always set X-XSS-Protection       "1; mode=block"
            Header always set Referrer-Policy        "strict-origin-when-cross-origin"
            # Ocultar versão do PHP
            Header unset X-Powered-By
        </IfModule>
    </Directory>

    # Bloquear acesso a arquivos sensíveis
    <FilesMatch "\.(sql|sh|md|env|log|bak|git)$">
        Require all denied
    </FilesMatch>

    # Bloquear acesso a pastas src/ e database/ diretamente
    <DirectoryMatch "^${APP_DIR}/(src|database)/">
        Require all denied
    </DirectoryMatch>

    # Compressão gzip
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css text/plain
        AddOutputFilterByType DEFLATE application/javascript application/json
    </IfModule>

    # Cache de assets
    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType text/css                "access plus 1 month"
        ExpiresByType application/javascript  "access plus 1 month"
        ExpiresByType image/jpeg              "access plus 1 month"
        ExpiresByType image/png              "access plus 1 month"
        ExpiresByType image/webp             "access plus 1 month"
    </IfModule>

    # Logs
    ErrorLog  \${APACHE_LOG_DIR}/lista-carioca-error.log
    CustomLog \${APACHE_LOG_DIR}/lista-carioca-access.log combined
</VirtualHost>
VHOST

# Desabilitar site padrão e ativar o nosso
a2dissite 000-default.conf 2>/dev/null || true
a2ensite  lista-carioca.conf

# Testar configuração
if apache2ctl configtest 2>/dev/null; then
    systemctl reload apache2
    log_ok "Virtual Host criado e Apache recarregado"
else
    log_warn "Erro na configuração do Apache. Verifique: apache2ctl configtest"
fi

# =============================================================================
#  11. OTIMIZAR PHP PARA PRODUÇÃO
# =============================================================================
log_header "Otimizando PHP e MySQL"

PHP_INI="/etc/php/${PHP_VERSION}/apache2/php.ini"

if [[ -f "$PHP_INI" ]]; then
    log_info "Ajustando php.ini..."

    declare -A php_settings=(
        ["expose_php"]="Off"
        ["display_errors"]="Off"
        ["log_errors"]="On"
        ["memory_limit"]="256M"
        ["upload_max_filesize"]="20M"
        ["post_max_size"]="25M"
        ["max_execution_time"]="60"
        ["max_input_vars"]="3000"
        ["date.timezone"]="America/Sao_Paulo"
        ["session.cookie_httponly"]="1"
        ["session.cookie_secure"]="0"
        ["session.use_strict_mode"]="1"
        ["session.gc_maxlifetime"]="7200"
    )

    for key in "${!php_settings[@]}"; do
        val="${php_settings[$key]}"
        # Substituir se existir, adicionar se não existir
        if grep -qE "^;?${key}\s*=" "$PHP_INI" 2>/dev/null; then
            sed -i "s|^;*${key}\s*=.*|${key} = ${val}|" "$PHP_INI"
        else
            echo "${key} = ${val}" >> "$PHP_INI"
        fi
        log_sub "${key} = ${val}"
    done

    # OPcache para produção
    OPCACHE_INI="/etc/php/${PHP_VERSION}/mods-available/opcache.ini"
    if [[ -f "$OPCACHE_INI" ]]; then
        cat >> "$OPCACHE_INI" << 'OPCACHE'

; Otimizações Lista Carioca
opcache.enable=1
opcache.enable_cli=0
opcache.memory_consumption=128
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=10000
opcache.revalidate_freq=60
opcache.fast_shutdown=1
OPCACHE
        log_sub "OPcache configurado"
    fi

    systemctl reload apache2
    log_ok "PHP otimizado"
else
    log_warn "php.ini não encontrado em ${PHP_INI} — ajustes pulados"
fi

# MySQL — ajustes básicos
MYSQL_CONF="/etc/mysql/mysql.conf.d/mysqld.cnf"
if [[ -f "$MYSQL_CONF" ]]; then
    log_info "Ajustando MySQL..."
    # Adicionar apenas se ainda não tiver nossa seção
    if ! grep -q "Lista Carioca" "$MYSQL_CONF" 2>/dev/null; then
        cat >> "$MYSQL_CONF" << 'MYSQLCONF'

# Lista Carioca — otimizações
[mysqld]
innodb_buffer_pool_size    = 128M
innodb_log_file_size       = 32M
max_connections            = 100
query_cache_type           = 0
slow_query_log             = 1
slow_query_log_file        = /var/log/mysql/lista-carioca-slow.log
long_query_time            = 2
character-set-server       = utf8mb4
collation-server           = utf8mb4_unicode_ci
MYSQLCONF
        systemctl restart mysql
    fi
    log_ok "MySQL otimizado"
fi

# =============================================================================
#  12. EXTRAS: CRON + LOGROTATE + /ETC/HOSTS
# =============================================================================
log_header "Configurações finais"

# Cron — limpar sessões PHP expiradas
CRON_FILE="/etc/cron.d/lista-carioca"
cat > "$CRON_FILE" << CRON
# Lista Carioca — manutenção automática
# Limpar sessões PHP a cada hora
0 * * * * www-data find /var/lib/php/sessions -maxdepth 1 -type f -mmin +120 -delete 2>/dev/null
# Rotacionar log de acesso semanalmente
0 2 * * 0 root /usr/sbin/logrotate -f /etc/logrotate.d/lista-carioca 2>/dev/null
CRON
chmod 644 "$CRON_FILE"
log_ok "Cron configurado em ${CRON_FILE}"

# Logrotate
cat > "/etc/logrotate.d/lista-carioca" << LOGROTATE
/var/log/apache2/lista-carioca-*.log {
    weekly
    missingok
    rotate 8
    compress
    delaycompress
    notifempty
    sharedscripts
    postrotate
        /usr/bin/systemctl reload apache2 > /dev/null 2>&1 || true
    endscript
}
LOGROTATE
log_ok "Logrotate configurado"

# /etc/hosts para domínio local
if [[ "$APP_DOMAIN" == *".local" || "$APP_DOMAIN" == "localhost"* ]]; then
    if ! grep -q "$APP_DOMAIN" /etc/hosts 2>/dev/null; then
        echo "127.0.0.1  ${APP_DOMAIN}  www.${APP_DOMAIN}" >> /etc/hosts
        log_ok "${APP_DOMAIN} adicionado em /etc/hosts"
    else
        log_sub "${APP_DOMAIN} já existe em /etc/hosts"
    fi
fi

# =============================================================================
#  VERIFICAÇÃO FINAL
# =============================================================================
echo ""
echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}${BOLD}  VERIFICAÇÃO FINAL${NC}"
echo -e "${CYAN}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

ERRORS=0

# Apache
if systemctl is-active --quiet apache2; then
    log_ok "Apache2 rodando"
else
    log_warn "Apache2 NÃO está rodando"; ((ERRORS++))
fi

# MySQL
if systemctl is-active --quiet mysql; then
    log_ok "MySQL rodando"
else
    log_warn "MySQL NÃO está rodando"; ((ERRORS++))
fi

# PHP
PHP_OK=$(php -r "echo 'ok';" 2>/dev/null || echo "")
if [[ "$PHP_OK" == "ok" ]]; then
    log_ok "PHP $(php -r 'echo PHP_VERSION;') funcionando"
else
    log_warn "PHP com problema"; ((ERRORS++))
fi

# PDO MySQL
PDO_OK=$(php -r "try { new PDO('mysql:host=${DB_HOST};dbname=${DB_NAME}','${DB_USER}','${DB_PASS}'); echo 'ok'; } catch(Exception \$e) { echo 'fail'; }" 2>/dev/null)
if [[ "$PDO_OK" == "ok" ]]; then
    log_ok "Conexão PDO com banco de dados OK"
else
    log_warn "Falha na conexão PDO com banco"; ((ERRORS++))
fi

# index.php existe
if [[ -f "${APP_DIR}/public/index.php" ]]; then
    log_ok "index.php encontrado"
else
    log_warn "index.php não encontrado"; ((ERRORS++))
fi

# .htaccess existe
if [[ -f "${APP_DIR}/public/.htaccess" ]]; then
    log_ok ".htaccess encontrado"
else
    log_warn ".htaccess não encontrado"; ((ERRORS++))
fi

# mod_rewrite ativo
if apache2ctl -M 2>/dev/null | grep -q rewrite; then
    log_ok "mod_rewrite ativo"
else
    log_warn "mod_rewrite não detectado"; ((ERRORS++))
fi

# =============================================================================
#  SALVAR CREDENCIAIS
# =============================================================================
CREDS_FILE="/root/.lista-carioca-install.txt"
cat > "$CREDS_FILE" << CREDS
╔═══════════════════════════════════════════════╗
║  Lista Carioca — Credenciais de Instalação    ║
╚═══════════════════════════════════════════════╝

Data da instalação: $(date)
Servidor: $(hostname)

─── ACESSO AO SITE ──────────────────────────────
URL:          http://${APP_DOMAIN}
Diretório:    ${APP_DIR}

─── BANCO DE DADOS ──────────────────────────────
Host:         ${DB_HOST}:${DB_PORT}
Banco:        ${DB_NAME}
Usuário:      ${DB_USER}
Senha:        ${DB_PASS}

─── USUÁRIOS DO SISTEMA ─────────────────────────
Admin:        admin@listacarioca.com.br / password
Parceiro 1:   ana@salaobeladona.com / password
Parceiro 2:   carlos@studiohair.com / password
Cliente:      maria@email.com / password

─── CAMINHOS ÚTEIS ──────────────────────────────
App:          ${APP_DIR}
Logs Apache:  /var/log/apache2/lista-carioca-*.log
PHP ini:      /etc/php/${PHP_VERSION}/apache2/php.ini
VHost:        /etc/apache2/sites-available/lista-carioca.conf
Cron:         /etc/cron.d/lista-carioca

─── COMANDOS ÚTEIS ──────────────────────────────
Reiniciar Apache:  systemctl restart apache2
Reiniciar MySQL:   systemctl restart mysql
Logs em tempo real: tail -f /var/log/apache2/lista-carioca-error.log
CREDS
chmod 600 "$CREDS_FILE"

# =============================================================================
#  RESUMO FINAL
# =============================================================================
echo ""
echo -e "${GREEN}${BOLD}╔═══════════════════════════════════════════════════════╗${NC}"
if [[ $ERRORS -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}║   ✅  INSTALAÇÃO CONCLUÍDA COM SUCESSO!               ║${NC}"
else
    echo -e "${YELLOW}${BOLD}║   ⚠️   INSTALAÇÃO CONCLUÍDA COM ${ERRORS} AVISO(S)          ║${NC}"
fi
echo -e "${GREEN}${BOLD}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}🌐 Acesse o site:${NC}"
echo -e "     ${CYAN}http://${APP_DOMAIN}${NC}"
echo ""
echo -e "  ${BOLD}🔐 Login de acesso:${NC}"
echo -e "     Admin    → ${YELLOW}admin@listacarioca.com.br${NC} / ${YELLOW}password${NC}"
echo -e "     Parceiro → ${YELLOW}ana@salaobeladona.com${NC} / ${YELLOW}password${NC}"
echo -e "     Cliente  → ${YELLOW}maria@email.com${NC} / ${YELLOW}password${NC}"
echo ""
echo -e "  ${BOLD}🗄️  Banco de dados:${NC}"
echo -e "     Banco:   ${YELLOW}${DB_NAME}${NC}"
echo -e "     Usuário: ${YELLOW}${DB_USER}${NC}"
echo -e "     Senha:   ${YELLOW}${DB_PASS}${NC}"
echo ""
echo -e "  ${BOLD}📁 Arquivos:${NC}"
echo -e "     App:    ${YELLOW}${APP_DIR}${NC}"
echo -e "     Logs:   ${YELLOW}/var/log/apache2/lista-carioca-error.log${NC}"
echo ""
echo -e "  ${BOLD}🔧 Comandos úteis:${NC}"
echo -e "     ${CYAN}systemctl restart apache2${NC}   → Reiniciar Apache"
echo -e "     ${CYAN}systemctl restart mysql${NC}     → Reiniciar MySQL"
echo -e "     ${CYAN}tail -f /var/log/apache2/lista-carioca-error.log${NC}"
echo ""
echo -e "  ${BOLD}💾 Credenciais salvas em:${NC} ${YELLOW}${CREDS_FILE}${NC}"
echo ""
[[ $ERRORS -gt 0 ]] && echo -e "  ${YELLOW}⚠  Verifique os avisos acima antes de usar o sistema.${NC}\n"
