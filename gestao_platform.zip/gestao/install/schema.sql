-- ============================================================
--  GESTÃO ADMINISTRATIVA — Schema Completo
--  Execute: mysql -u gestao -p gestao < schema.sql
-- ============================================================
SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ── CORE ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `filiais` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `nome`       VARCHAR(120) NOT NULL,
  `endereco`   VARCHAR(255),
  `cidade`     VARCHAR(80),
  `estado`     CHAR(2),
  `cep`        VARCHAR(10),
  `telefone`   VARCHAR(20),
  `email`      VARCHAR(120),
  `responsavel` VARCHAR(120),
  `ativa`      TINYINT(1) DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `users` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `nome`       VARCHAR(120) NOT NULL,
  `username`   VARCHAR(80)  NOT NULL UNIQUE,
  `email`      VARCHAR(150) NOT NULL UNIQUE,
  `password`   VARCHAR(255) NOT NULL,
  `perfil`     ENUM('admin','gestor','operador','visualizador') DEFAULT 'operador',
  `filial_id`  INT,
  `avatar`     VARCHAR(200),
  `ativo`      TINYINT(1) DEFAULT 1,
  `ultimo_acesso` DATETIME,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`) REFERENCES `filiais`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `permissoes` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT NOT NULL,
  `modulo`     VARCHAR(60) NOT NULL,
  `acao`       ENUM('ver','criar','editar','excluir') NOT NULL,
  UNIQUE KEY `uq_perm` (`user_id`,`modulo`,`acao`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `activity_log` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT,
  `modulo`     VARCHAR(60),
  `acao`       VARCHAR(120),
  `detalhes`   TEXT,
  `ip`         VARCHAR(45),
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── TAREFAS / AGENDA ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `tarefas` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `titulo`      VARCHAR(200) NOT NULL,
  `descricao`   TEXT,
  `status`      ENUM('pendente','em_andamento','concluida','cancelada') DEFAULT 'pendente',
  `prioridade`  ENUM('baixa','media','alta','urgente') DEFAULT 'media',
  `responsavel_id` INT,
  `filial_id`   INT,
  `data_inicio` DATE,
  `data_fim`    DATE,
  `data_conclusao` DATETIME,
  `criado_por`  INT,
  `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`responsavel_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`filial_id`)      REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`criado_por`)     REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lembretes` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `titulo`      VARCHAR(200) NOT NULL,
  `descricao`   TEXT,
  `user_id`     INT NOT NULL,
  `data_hora`   DATETIME NOT NULL,
  `recorrencia` ENUM('nenhuma','diaria','semanal','mensal') DEFAULT 'nenhuma',
  `notificado`  TINYINT(1) DEFAULT 0,
  `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── CHAMADOS ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `chamados` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `numero`        VARCHAR(20) NOT NULL UNIQUE,
  `titulo`        VARCHAR(200) NOT NULL,
  `descricao`     TEXT,
  `categoria`     ENUM('ti','predial','administrativo','financeiro','rh','outros') DEFAULT 'outros',
  `prioridade`    ENUM('baixa','media','alta','critica') DEFAULT 'media',
  `status`        ENUM('aberto','em_atendimento','aguardando','resolvido','fechado') DEFAULT 'aberto',
  `filial_id`     INT,
  `aberto_por`    INT,
  `atendente_id`  INT,
  `sla_horas`     INT DEFAULT 24,
  `prazo_sla`     DATETIME,
  `data_resolucao` DATETIME,
  `avaliacao`     TINYINT,
  `obs_avaliacao` TEXT,
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)    REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`aberto_por`)   REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`atendente_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `chamados_historico` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `chamado_id` INT NOT NULL,
  `user_id`    INT,
  `acao`       VARCHAR(120),
  `mensagem`   TEXT,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`chamado_id`) REFERENCES `chamados`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`)    REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── ATIVOS ───────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `equipamentos` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `codigo`       VARCHAR(40) NOT NULL UNIQUE,
  `nome`         VARCHAR(150) NOT NULL,
  `tipo`         ENUM('computador','impressora','servidor','telefone','ar_condicionado','camera','outros') DEFAULT 'outros',
  `marca`        VARCHAR(80),
  `modelo`       VARCHAR(80),
  `numero_serie` VARCHAR(80),
  `filial_id`    INT,
  `localizacao`  VARCHAR(150),
  `status`       ENUM('ativo','manutencao','inativo','descartado') DEFAULT 'ativo',
  `data_aquisicao` DATE,
  `valor`        DECIMAL(12,2),
  `garantia_ate` DATE,
  `responsavel_id` INT,
  `obs`          TEXT,
  `created_at`   DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)      REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`responsavel_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `predial` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `filial_id`  INT NOT NULL,
  `area`       VARCHAR(120) NOT NULL,
  `tipo`       ENUM('eletrica','hidraulica','civil','ar_condicionado','seguranca','outros') DEFAULT 'outros',
  `descricao`  TEXT,
  `status`     ENUM('ok','atencao','critico') DEFAULT 'ok',
  `responsavel_id` INT,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)      REFERENCES `filiais`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`responsavel_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `manutencoes` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `tipo_ref`       ENUM('equipamento','predial') NOT NULL,
  `ref_id`         INT NOT NULL,
  `tipo`           ENUM('preventiva','corretiva','preditiva') DEFAULT 'corretiva',
  `titulo`         VARCHAR(200) NOT NULL,
  `descricao`      TEXT,
  `status`         ENUM('agendada','em_andamento','concluida','cancelada') DEFAULT 'agendada',
  `fornecedor_id`  INT,
  `responsavel_id` INT,
  `data_agendada`  DATE,
  `data_realizada` DATE,
  `custo`          DECIMAL(12,2),
  `obs`            TEXT,
  `created_at`     DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`fornecedor_id`)  REFERENCES `fornecedores`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`responsavel_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── FORNECEDORES (CRM) ────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `fornecedores` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `razao_social` VARCHAR(200) NOT NULL,
  `nome_fantasia` VARCHAR(200),
  `cnpj`        VARCHAR(20) UNIQUE,
  `categoria`   VARCHAR(80),
  `telefone`    VARCHAR(20),
  `email`       VARCHAR(120),
  `site`        VARCHAR(200),
  `contato`     VARCHAR(120),
  `endereco`    VARCHAR(255),
  `cidade`      VARCHAR(80),
  `estado`      CHAR(2),
  `status`      ENUM('ativo','inativo','bloqueado') DEFAULT 'ativo',
  `avaliacao_media` DECIMAL(3,2) DEFAULT 0,
  `obs`         TEXT,
  `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `fornecedores_servicos` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `fornecedor_id` INT NOT NULL,
  `descricao`     VARCHAR(200) NOT NULL,
  `valor`         DECIMAL(12,2),
  `unidade`       VARCHAR(40),
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `fornecedores_avaliacoes` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `fornecedor_id` INT NOT NULL,
  `user_id`       INT,
  `nota`          TINYINT NOT NULL,
  `comentario`    TEXT,
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`)       REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `atendimentos` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `fornecedor_id` INT NOT NULL,
  `titulo`        VARCHAR(200),
  `descricao`     TEXT,
  `valor`         DECIMAL(12,2),
  `data`          DATE,
  `status`        ENUM('agendado','realizado','cancelado') DEFAULT 'agendado',
  `chamado_id`    INT,
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`chamado_id`)    REFERENCES `chamados`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── FINANCEIRO ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `despesas` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `titulo`        VARCHAR(200) NOT NULL,
  `descricao`     TEXT,
  `categoria`     ENUM('manutencao','fornecedor','aluguel','utilidades','ti','administrativo','outros') DEFAULT 'outros',
  `valor`         DECIMAL(12,2) NOT NULL,
  `data`          DATE NOT NULL,
  `status`        ENUM('pendente','aprovada','paga','rejeitada') DEFAULT 'pendente',
  `filial_id`     INT,
  `fornecedor_id` INT,
  `solicitante_id` INT,
  `aprovador_id`  INT,
  `data_aprovacao` DATETIME,
  `data_pagamento` DATE,
  `comprovante`   VARCHAR(200),
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)      REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`fornecedor_id`)  REFERENCES `fornecedores`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`solicitante_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`aprovador_id`)   REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `notas_fiscais` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `numero`        VARCHAR(60) NOT NULL,
  `serie`         VARCHAR(10),
  `fornecedor_id` INT,
  `valor`         DECIMAL(12,2) NOT NULL,
  `data_emissao`  DATE NOT NULL,
  `data_vencimento` DATE,
  `status`        ENUM('pendente','paga','cancelada','vencida') DEFAULT 'pendente',
  `despesa_id`    INT,
  `arquivo`       VARCHAR(200),
  `obs`           TEXT,
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`despesa_id`)    REFERENCES `despesas`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── CONTRATOS ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `contratos` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `numero`        VARCHAR(60) NOT NULL,
  `titulo`        VARCHAR(200) NOT NULL,
  `tipo`          ENUM('aluguel','servico','manutencao','fornecimento','outros') DEFAULT 'outros',
  `filial_id`     INT,
  `fornecedor_id` INT,
  `valor_mensal`  DECIMAL(12,2),
  `valor_total`   DECIMAL(12,2),
  `data_inicio`   DATE,
  `data_fim`      DATE,
  `status`        ENUM('ativo','vencendo','vencido','encerrado','cancelado') DEFAULT 'ativo',
  `alerta_dias`   INT DEFAULT 30,
  `arquivo`       VARCHAR(200),
  `obs`           TEXT,
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)     REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── PROCESSOS ADMINISTRATIVOS ─────────────────────────────────

CREATE TABLE IF NOT EXISTS `processos` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `titulo`      VARCHAR(200) NOT NULL,
  `tipo`        ENUM('prefeitura','licenca','documentacao','outros') DEFAULT 'outros',
  `orgao`       VARCHAR(120),
  `numero_processo` VARCHAR(80),
  `descricao`   TEXT,
  `status`      ENUM('em_andamento','concluido','pendente','vencido') DEFAULT 'em_andamento',
  `filial_id`   INT,
  `responsavel_id` INT,
  `data_inicio` DATE,
  `data_prazo`  DATE,
  `data_conclusao` DATE,
  `alerta_dias` INT DEFAULT 30,
  `arquivo`     VARCHAR(200),
  `obs`         TEXT,
  `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)      REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`responsavel_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── ACHADOS E PERDIDOS ────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `achados_perdidos` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `titulo`        VARCHAR(200) NOT NULL,
  `descricao`     TEXT,
  `categoria`     ENUM('documento','eletronico','vestuario','acessorio','outros') DEFAULT 'outros',
  `filial_id`     INT,
  `local_encontrado` VARCHAR(200),
  `data_encontrado` DATE NOT NULL,
  `encontrado_por` VARCHAR(120),
  `status`        ENUM('guardado','entregue','doado','enviado_caju','descartado') DEFAULT 'guardado',
  `proprietario`  VARCHAR(120),
  `data_devolucao` DATE,
  `destinacao`    ENUM('devolucao','doacao','caju_rj','descarte') DEFAULT 'devolucao',
  `obs_destinacao` TEXT,
  `registrado_por` INT,
  `foto`          VARCHAR(200),
  `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`filial_id`)     REFERENCES `filiais`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`registrado_por`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── NOTIFICAÇÕES ──────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `notificacoes` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT NOT NULL,
  `titulo`     VARCHAR(200),
  `mensagem`   TEXT,
  `tipo`       ENUM('info','aviso','alerta','sucesso') DEFAULT 'info',
  `modulo`     VARCHAR(60),
  `ref_id`     INT,
  `lida`       TINYINT(1) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET foreign_key_checks = 1;

-- ── DADOS INICIAIS ────────────────────────────────────────────
INSERT IGNORE INTO `filiais` (nome, cidade, estado, ativa) VALUES
  ('Matriz', 'Rio de Janeiro', 'RJ', 1),
  ('Filial Norte', 'Rio de Janeiro', 'RJ', 1),
  ('Filial Sul', 'Rio de Janeiro', 'RJ', 1);
