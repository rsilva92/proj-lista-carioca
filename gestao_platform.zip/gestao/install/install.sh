#!/bin/bash
# ============================================================
#  GESTÃO ADMINISTRATIVA — Instalador Automático
#  Ubuntu 20.04 / 22.04 / 24.04 — Apache2 + PHP + MySQL
# ============================================================
set -e
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'
log()  { echo -e "  ${GRN}✓${RST} $1"; }
warn() { echo -e "  ${YLW}!${RST} $1"; }
err()  { echo -e "  ${RED}✗${RST} $1"; exit 1; }
step() { echo -e "\n  ${CYN}▶${RST} ${BLD}$1${RST}"; }

[ "$EUID" -ne 0 ] && err "Execute como root: sudo bash install.sh"

echo -e "\n  ${CYN}${BLD}╔════════════════════════════════════════════╗${RST}"
echo -e "  ${CYN}${BLD}║   GESTÃO ADMINISTRATIVA — Instalador       ║${RST}"
echo -e "  ${CYN}${BLD}╚════════════════════════════════════════════╝${RST}\n"

echo -e "  ${BLD}Modo de instalação:${RST}"
echo -e "    ${CYN}1${RST}) Subpasta  — http://IP/gestao   ${YLW}(recomendado)${RST}"
echo -e "    ${CYN}2${RST}) Domínio   — http://gestao.empresa.com"
echo ""
read -p "  Escolha [1]: " INSTALL_MODE
INSTALL_MODE="${INSTALL_MODE:-1}"

if [ "$INSTALL_MODE" = "1" ]; then
  read -p "  Nome da subpasta [gestao]: " INPUT_SUBDIR
  SUBDIR="${INPUT_SUBDIR:-gestao}"
  SUBDIR="${SUBDIR#/}"

  # Detect DocumentRoot — apachectl -S outputs "DocumentRoot: /path" or "DocumentRoot /path"
  # The sed strips everything before and including the colon/space
  APACHE_DOCROOT_RAW=$(apachectl -S 2>/dev/null | grep -i "DocumentRoot" | head -1)
  APACHE_DOCROOT=$(echo "$APACHE_DOCROOT_RAW" | sed 's/.*DocumentRoot[: ]*//' | tr -d '"' | tr -d "'" | xargs)
  if [ -z "$APACHE_DOCROOT" ] || [ ! -d "$APACHE_DOCROOT" ]; then
    APACHE_DOCROOT="/var/www/html"
  fi
  APACHE_DOCROOT="${APACHE_DOCROOT%/}"

  echo -e "  DocumentRoot detectado: ${CYN}$APACHE_DOCROOT${RST}"
  read -p "  Confirme o DocumentRoot [$APACHE_DOCROOT]: " INPUT_DOCROOT
  APACHE_DOCROOT="${INPUT_DOCROOT:-$APACHE_DOCROOT}"
  APACHE_DOCROOT="${APACHE_DOCROOT%/}"

  SITE_DIR="$APACHE_DOCROOT/$SUBDIR"
  APP_BASE="/$SUBDIR"
  APP_URL="http://$(hostname -I | awk '{print $1}')/$SUBDIR"
else
  read -p "  Domínio [gestao.empresa.com]: " VHOST_DOMAIN
  VHOST_DOMAIN="${VHOST_DOMAIN:-gestao.empresa.com}"
  SITE_DIR="/var/www/${VHOST_DOMAIN//./_}"
  APP_BASE=""
  APP_URL="http://$VHOST_DOMAIN"
  SUBDIR=""
fi

DB_NAME="gestao"; DB_USER="gestao"
read -s -p "  Senha MySQL para '$DB_USER': " DB_PASS; echo ""
[ -z "$DB_PASS" ] && DB_PASS="gestao$(date +%s | sha256sum | head -c 8)" && warn "Senha gerada: $DB_PASS"

read -p "  Nome do usuário admin [admin]: " ADMIN_USER; ADMIN_USER="${ADMIN_USER:-admin}"
read -p "  Nome completo do admin [Administrador]: " ADMIN_NOME; ADMIN_NOME="${ADMIN_NOME:-Administrador}"
read -p "  E-mail do admin [admin@empresa.com]: " ADMIN_EMAIL; ADMIN_EMAIL="${ADMIN_EMAIL:-admin@empresa.com}"
read -s -p "  Senha do admin: " ADMIN_PASS; echo ""
[ -z "$ADMIN_PASS" ] && ADMIN_PASS="Admin@2025" && warn "Senha padrão: $ADMIN_PASS (ALTERE AO ENTRAR!)"
read -p "  Senha root MySQL [Enter = auth socket]: " DB_ROOT_PASS; echo ""

step "Instalando pacotes"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 php8.2 php8.2-mysql php8.2-mbstring php8.2-xml php8.2-curl php8.2-zip php8.2-gd \
  mysql-server libapache2-mod-php8.2 unzip curl rsync 2>/dev/null || \
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 php8.1 php8.1-mysql php8.1-mbstring php8.1-xml php8.1-curl php8.1-zip php8.1-gd \
  mysql-server libapache2-mod-php8.1 unzip curl rsync 2>/dev/null || \
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 php php-mysql php-mbstring php-xml php-curl php-zip php-gd \
  mysql-server libapache2-mod-php unzip curl rsync
a2enmod rewrite headers expires deflate
log "Pacotes instalados"

step "Criando banco de dados"
[ -n "$DB_ROOT_PASS" ] && MYSQL="mysql -u root -p${DB_ROOT_PASS}" || MYSQL="mysql -u root"
ADMIN_HASH=$(php -r "echo password_hash('$ADMIN_PASS', PASSWORD_BCRYPT);")
$MYSQL << SQLEOF
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
SQLEOF
$MYSQL $DB_NAME < "$(dirname "${BASH_SOURCE[0]}")/schema.sql"
$MYSQL $DB_NAME << SQLEOF
INSERT IGNORE INTO users (nome, username, email, password, perfil)
VALUES ('$ADMIN_NOME', '$ADMIN_USER', '$ADMIN_EMAIL', '$ADMIN_HASH', 'admin');
SQLEOF
log "Banco '$DB_NAME' criado"

step "Copiando arquivos"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Safety check: prevent copying into itself
if [ "$SITE_DIR" = "$SCRIPT_DIR" ] || [[ "$SITE_DIR" == "$SCRIPT_DIR/"* ]]; then
  err "SITE_DIR ($SITE_DIR) está dentro do diretório de origem ($SCRIPT_DIR). Verifique o DocumentRoot."
fi

mkdir -p "$SITE_DIR/exports"
mkdir -p "$SITE_DIR/uploads"

# Use rsync if available (preferred — supports --exclude properly)
if command -v rsync &>/dev/null; then
  rsync -a     --exclude='install/'     --exclude='exports/'     --exclude='uploads/'     "$SCRIPT_DIR/" "$SITE_DIR/"
  log "Arquivos copiados com rsync"
else
  # Fallback: cp individual dirs/files except install, exports, uploads
  for item in "$SCRIPT_DIR"/*/; do
    dirname=$(basename "$item")
    case "$dirname" in
      install|exports|uploads) continue ;;
    esac
    cp -r "$item" "$SITE_DIR/"
  done
  # Copy root-level files
  find "$SCRIPT_DIR" -maxdepth 1 -type f -exec cp {} "$SITE_DIR/" \;
  log "Arquivos copiados com cp"
fi
log "Arquivos em $SITE_DIR"

step "Gerando config.php"
cat > "$SITE_DIR/includes/config.php" << PHPEOF
<?php
define('DB_HOST',    'localhost');
define('DB_NAME',    '$DB_NAME');
define('DB_USER',    '$DB_USER');
define('DB_PASS',    '$DB_PASS');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME',   'Gestão Administrativa');
define('APP_VERSION','1.0.0');
define('APP_URL',    '$APP_URL');
define('APP_BASE',   '$APP_BASE');
define('EXPORT_DIR', __DIR__ . '/../exports/');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('SESSION_LIFETIME', 86400 * 30);

function url(string \$path = '/'): string {
    \$base = rtrim(APP_BASE, '/');
    if (\$path === '/') return \$base . '/';
    return \$base . '/' . ltrim(\$path, '/');
}

function asset(string \$path): string {
    return url('/assets/' . ltrim(\$path, '/'));
}
PHPEOF
log "config.php gerado"

step "Configurando Apache"
REWRITE_BASE="${APP_BASE:-/}/"
sed -i "s|RewriteBase /gestao/|RewriteBase $REWRITE_BASE|" "$SITE_DIR/public/.htaccess"

if [ "$INSTALL_MODE" = "1" ]; then
  MAIN_CONF="/etc/apache2/apache2.conf"
  sed -i '/^<Directory \/var\/www\/>/,/^<\/Directory>/ s/AllowOverride None/AllowOverride All/' "$MAIN_CONF" || true
  DEFAULT_CONF="/etc/apache2/sites-enabled/000-default.conf"
  [ -f "$DEFAULT_CONF" ] && sed -i 's/AllowOverride None/AllowOverride All/g' "$DEFAULT_CONF" || true

  ALIAS_CONF="/etc/apache2/conf-available/${SUBDIR}_gestao.conf"
  cat > "$ALIAS_CONF" << APACHEEOF
Alias /$SUBDIR "$SITE_DIR/public"

<Directory "$SITE_DIR/public">
    Options +FollowSymLinks -Indexes
    AllowOverride All
    Require all granted
</Directory>

<Directory "$SITE_DIR/includes">
    Require all denied
</Directory>

<Directory "$SITE_DIR/data">
    Require all denied
</Directory>
APACHEEOF
  a2enconf "${SUBDIR}_gestao"
  log "Alias /$SUBDIR configurado"
else
  cat > "/etc/apache2/sites-available/${VHOST_DOMAIN//./_}.conf" << APACHEEOF
<VirtualHost *:80>
    ServerName $VHOST_DOMAIN
    DocumentRoot $SITE_DIR/public
    DirectoryIndex index.php
    <Directory $SITE_DIR/public>
        Options +FollowSymLinks -Indexes
        AllowOverride All
        Require all granted
    </Directory>
    <Directory $SITE_DIR/includes>
        Require all denied
    </Directory>
</VirtualHost>
APACHEEOF
  a2ensite "${VHOST_DOMAIN//./_}"
  log "VirtualHost $VHOST_DOMAIN criado"
fi

step "Permissões"
chown -R www-data:www-data "$SITE_DIR"
chmod -R 755 "$SITE_DIR"
chmod -R 775 "$SITE_DIR/exports" "$SITE_DIR/uploads"
log "Permissões configuradas"

apache2ctl configtest 2>&1 | grep -q "Syntax OK" && log "Apache: Syntax OK" || warn "Verifique a config do Apache"
systemctl reload apache2
log "Apache recarregado"

IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "  ╔══════════════════════════════════════════════════════╗"
echo -e "  ║  ${GRN}${BLD}INSTALAÇÃO CONCLUÍDA!${RST}"
echo -e "  ╠══════════════════════════════════════════════════════╣"
echo -e "  ║  ${BLD}URL:${RST}      ${CYN}$APP_URL${RST}"
echo -e "  ║  ${BLD}Usuário:${RST}  $ADMIN_USER"
echo -e "  ║  ${BLD}Senha:${RST}    ${YLW}$ADMIN_PASS${RST}"
echo -e "  ║  ${BLD}DB:${RST}       $DB_NAME / $DB_USER"
echo -e "  ╚══════════════════════════════════════════════════════╝"
