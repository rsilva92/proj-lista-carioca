-- ============================================================
--  GESTÃO ADMINISTRATIVA — Schema de Atualização
--  Execute APÓS o schema.sql inicial:
--  mysql -u gestao -p gestao < schema_update.sql
-- ============================================================
SET NAMES utf8mb4;

-- Tabela universal de comentários
CREATE TABLE IF NOT EXISTS `comentarios` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `modulo`     VARCHAR(60) NOT NULL,
  `ref_id`     INT NOT NULL,
  `user_id`    INT,
  `texto`      TEXT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_modulo_ref` (`modulo`, `ref_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `equipamentos`
  ADD COLUMN IF NOT EXISTS `patrimonio`    VARCHAR(40)  AFTER `codigo`,
  ADD COLUMN IF NOT EXISTS `fornecedor_id` INT          AFTER `responsavel_id`,
  ADD COLUMN IF NOT EXISTS `vida_util`     INT          AFTER `garantia_ate`,
  ADD COLUMN IF NOT EXISTS `ip_address`    VARCHAR(45)  AFTER `numero_serie`,
  ADD COLUMN IF NOT EXISTS `hostname`      VARCHAR(80)  AFTER `ip_address`;

ALTER TABLE `predial`
  ADD COLUMN IF NOT EXISTS `metragem`         DECIMAL(10,2) AFTER `area`,
  ADD COLUMN IF NOT EXISTS `ultima_vistoria`  DATE AFTER `status`,
  ADD COLUMN IF NOT EXISTS `proxima_vistoria` DATE AFTER `ultima_vistoria`,
  ADD COLUMN IF NOT EXISTS `obs`              TEXT AFTER `descricao`,
  ADD COLUMN IF NOT EXISTS `updated_at`       DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE `manutencoes`
  ADD COLUMN IF NOT EXISTS `numero`      VARCHAR(30) AFTER `id`,
  ADD COLUMN IF NOT EXISTS `chamado_id`  INT AFTER `obs`,
  ADD COLUMN IF NOT EXISTS `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE `fornecedores`
  ADD COLUMN IF NOT EXISTS `inscricao_estadual` VARCHAR(30) AFTER `cnpj`,
  ADD COLUMN IF NOT EXISTS `cep`    VARCHAR(10) AFTER `endereco`,
  ADD COLUMN IF NOT EXISTS `bairro` VARCHAR(80) AFTER `cep`,
  ADD COLUMN IF NOT EXISTS `banco`  VARCHAR(60) AFTER `contato`,
  ADD COLUMN IF NOT EXISTS `agencia` VARCHAR(20) AFTER `banco`,
  ADD COLUMN IF NOT EXISTS `conta`   VARCHAR(30) AFTER `agencia`,
  ADD COLUMN IF NOT EXISTS `pix`     VARCHAR(100) AFTER `conta`;

ALTER TABLE `contratos`
  ADD COLUMN IF NOT EXISTS `responsavel_id`   INT AFTER `fornecedor_id`,
  ADD COLUMN IF NOT EXISTS `indice_reajuste`  VARCHAR(20) AFTER `valor_total`,
  ADD COLUMN IF NOT EXISTS `data_reajuste`    DATE AFTER `indice_reajuste`,
  ADD COLUMN IF NOT EXISTS `clausulas`        TEXT AFTER `obs`;

ALTER TABLE `processos`
  ADD COLUMN IF NOT EXISTS `custo`         DECIMAL(12,2) AFTER `data_conclusao`,
  ADD COLUMN IF NOT EXISTS `contato_orgao` VARCHAR(120) AFTER `orgao`,
  ADD COLUMN IF NOT EXISTS `prioridade`    ENUM('baixa','media','alta','urgente') DEFAULT 'media' AFTER `status`;

ALTER TABLE `despesas`
  ADD COLUMN IF NOT EXISTS `numero_nf`    VARCHAR(60) AFTER `comprovante`,
  ADD COLUMN IF NOT EXISTS `centro_custo` VARCHAR(80) AFTER `numero_nf`,
  ADD COLUMN IF NOT EXISTS `obs`          TEXT AFTER `centro_custo`,
  ADD COLUMN IF NOT EXISTS `updated_at`   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE `achados_perdidos`
  ADD COLUMN IF NOT EXISTS `cor`              VARCHAR(40) AFTER `descricao`,
  ADD COLUMN IF NOT EXISTS `marca`            VARCHAR(60) AFTER `cor`,
  ADD COLUMN IF NOT EXISTS `cpf_proprietario` VARCHAR(14) AFTER `proprietario`;

SELECT 'Schema atualizado!' AS resultado;
