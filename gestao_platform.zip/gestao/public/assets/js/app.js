'use strict';

// ── Sidebar ───────────────────────────────────────────────────
function toggleSidebar() {
  const sb  = document.getElementById('sidebar');
  const ov  = document.getElementById('sidebarOverlay');
  const mc  = document.getElementById('mainContent');
  if (!sb) return;
  const open = sb.classList.toggle('open');
  if (ov) ov.classList.toggle('open', open);
}

// ── Dropdowns ─────────────────────────────────────────────────
function toggleNotifs() {
  document.getElementById('notifDropdown')?.classList.toggle('open');
  document.getElementById('userDropdown')?.classList.remove('open');
}

function toggleUserMenu() {
  document.getElementById('userDropdown')?.classList.toggle('open');
  document.getElementById('notifDropdown')?.classList.remove('open');
}

document.addEventListener('click', e => {
  if (!e.target.closest('.notif-wrapper'))  document.getElementById('notifDropdown')?.classList.remove('open');
  if (!e.target.closest('.user-menu-wrapper')) document.getElementById('userDropdown')?.classList.remove('open');
});

// ── Mark notifications ────────────────────────────────────────
function markAllRead() {
  api('notif_mark_all').then(() => {
    document.querySelectorAll('.notif-item').forEach(el => el.classList.remove('unread'));
    const cnt = document.querySelector('.notif-count');
    if (cnt) cnt.remove();
  });
}

// ── Modal ──────────────────────────────────────────────────────
function openModal(id) {
  document.getElementById(id)?.classList.add('open');
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
  }
});
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// ── Tabs ───────────────────────────────────────────────────────
function switchTab(groupId, tabId, el) {
  // Hide all panes in group
  document.querySelectorAll(`[data-tab-group="${groupId}"]`).forEach(p => p.classList.remove('active'));
  // Deactivate all buttons in group
  document.querySelectorAll(`[data-tab-btn="${groupId}"]`).forEach(b => b.classList.remove('active'));
  // Show target pane
  document.getElementById(tabId)?.classList.add('active');
  // Activate button
  if (el) el.classList.add('active');
}

// ── AJAX ───────────────────────────────────────────────────────
async function api(action, data = {}) {
  const base = (typeof APP_BASE !== 'undefined' && APP_BASE) ? APP_BASE.replace(/\/$/, '') : '';
  try {
    const res = await fetch(base + '/api.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...data })
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
  } catch (e) {
    console.error('API error:', action, e);
    return { error: e.message };
  }
}

// ── Flash ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.flash').forEach(el => {
    setTimeout(() => { el.style.transition = 'opacity .5s'; el.style.opacity = '0'; }, 4000);
    setTimeout(() => el.remove(), 4600);
  });

  // Keyboard shortcut: Ctrl+/ to focus search
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === '/') {
      e.preventDefault();
      document.querySelector('.filter-input, .filter-search')?.focus();
    }
  });
});

// ── Confirm delete ─────────────────────────────────────────────
function confirmDelete(msg, href) {
  if (confirm(msg || 'Confirmar exclusão?')) {
    window.location.href = href;
  }
  return false;
}

// ── Form helpers ───────────────────────────────────────────────
function formClear(formId) {
  const form = document.getElementById(formId);
  if (form) form.reset();
}

// ── Date formatting ────────────────────────────────────────────
function diasParaVencer(dateStr) {
  if (!dateStr) return null;
  const diff = Math.ceil((new Date(dateStr) - new Date()) / 86400000);
  return diff;
}

// ── SLA indicator ──────────────────────────────────────────────
function slaClass(prazoStr) {
  if (!prazoStr) return '';
  const hours = (new Date(prazoStr) - new Date()) / 3600000;
  if (hours < 0) return 'sla-danger';
  if (hours < 4) return 'sla-danger';
  if (hours < 24) return 'sla-warn';
  return 'sla-ok';
}

// ── Currency input mask ────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.money-input').forEach(el => {
    el.addEventListener('input', function() {
      let v = this.value.replace(/\D/g,'');
      if (!v) return;
      v = (parseInt(v) / 100).toFixed(2);
      this.value = v.replace('.', ',');
    });
  });
});

// ── Search filter (client-side table) ─────────────────────────
function tableSearch(inputId, tableId) {
  const input = document.getElementById(inputId);
  const table = document.getElementById(tableId);
  if (!input || !table) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}
