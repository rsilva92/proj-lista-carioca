<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/core.php';
Auth::start();
if (Auth::id()) { header('Location: ' . url('/')); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (Auth::login($_POST['username'] ?? '', $_POST['password'] ?? '')) {
        header('Location: ' . url('/')); exit;
    }
    $error = 'Usuário ou senha incorretos.';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Entrar — <?= APP_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400&family=Geist:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo-wrap">
      <div class="auth-logo-mark">GA</div>
      <div class="auth-logo-text">Gestão <span>Admin</span></div>
    </div>
    <h1 class="auth-title">Entrar no sistema</h1>
    <p class="auth-sub">Plataforma de gestão administrativa</p>

    <?php if ($error): ?>
    <div class="flash flash-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group" style="margin-bottom:14px">
        <label class="form-label">Usuário ou E-mail</label>
        <input class="form-input" type="text" name="username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
               placeholder="usuario ou email@empresa.com" required autofocus>
      </div>
      <div class="form-group" style="margin-bottom:20px">
        <label class="form-label">Senha</label>
        <input class="form-input" type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:11px;font-size:.95rem">
        → Entrar
      </button>
    </form>

    <p style="margin-top:20px;font-size:.78rem;color:var(--t3);text-align:center">
      Gestão Administrativa v<?= APP_VERSION ?>
    </p>
  </div>
</div>
</body>
</html>
