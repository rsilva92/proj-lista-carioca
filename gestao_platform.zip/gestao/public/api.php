<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/core.php';
header('Content-Type: application/json');
Auth::start();
$uid = Auth::id();
if (!$uid) { http_response_code(401); echo json_encode(['error'=>'unauthenticated']); exit; }

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';

switch ($action) {
    case 'notif_mark_all':
        Notif::markAllRead();
        echo json_encode(['ok' => true]);
        break;
    case 'notif_mark':
        Notif::markRead((int)($body['id'] ?? 0));
        echo json_encode(['ok' => true]);
        break;
    case 'notif_count':
        echo json_encode(['count' => Notif::unreadCount()]);
        break;
    case 'comentario_criar':
        $modulo = substr($body['modulo'] ?? '', 0, 60);
        $refId  = (int)($body['ref_id'] ?? 0);
        $texto  = trim($body['texto'] ?? '');
        if (!$modulo || !$refId || !$texto) { echo json_encode(['error'=>'invalid']); break; }
        $id = DB::insert(
            'INSERT INTO comentarios (modulo, ref_id, user_id, texto) VALUES (?,?,?,?)',
            [$modulo, $refId, $uid, $texto]
        );
        $nome = DB::one('SELECT nome FROM users WHERE id=?', [$uid])['nome'] ?? 'Usuário';
        $data = date('d/m/Y H:i');
        $ini  = strtoupper(substr($nome, 0, 2));
        $html = "<div class='comentario-item' id='cmt-$id'>"
              . "<div class='comentario-header'>"
              . "<div class='comentario-avatar'>$ini</div>"
              . "<div><strong class='comentario-autor'>" . htmlspecialchars($nome) . "</strong>"
              . "<span class='comentario-data text-xs text-muted'> $data</span></div>"
              . "<button class='btn btn-xs btn-ghost' style='margin-left:auto;color:var(--red)'"
              . " onclick="excluirComentario($id,'$modulo',$refId)">✕</button>"
              . "</div><div class='comentario-texto'>" . nl2br(htmlspecialchars($texto)) . "</div></div>";
        echo json_encode(['ok'=>true, 'id'=>$id, 'html'=>$html]);
        break;

    case 'comentario_excluir':
        $id  = (int)($body['id'] ?? 0);
        $cmt = DB::one('SELECT * FROM comentarios WHERE id=?', [$id]);
        if ($cmt && ($cmt['user_id'] == $uid || Auth::isAdmin())) {
            DB::run('DELETE FROM comentarios WHERE id=?', [$id]);
            echo json_encode(['ok'=>true]);
        } else {
            echo json_encode(['error'=>'forbidden']);
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'unknown_action']);
}
