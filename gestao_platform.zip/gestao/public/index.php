<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/core.php';
require_once __DIR__ . '/../includes/layout.php';

Auth::start(); Auth::require();

// ── Dashboard metrics ─────────────────────────────────────────
$tarefasPendentes  = DB::count('tarefas',  "status IN ('pendente','em_andamento') AND (responsavel_id=? OR criado_por=?)", [Auth::id(), Auth::id()]);
$chamadosAbertos   = DB::count('chamados', "status IN ('aberto','em_atendimento')");
$chamadosCriticos  = DB::count('chamados', "status IN ('aberto','em_atendimento') AND prioridade IN ('alta','critica')");
$contratoVencendo  = DB::count('contratos', "status='ativo' AND data_fim BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)");
$equipamentosAtivos= DB::count('equipamentos', "status='ativo'");
$achados           = DB::count('achados_perdidos', "status='guardado'");
$despesasPendentes = DB::one("SELECT SUM(valor) as total FROM despesas WHERE status='pendente'");
$processosVencendo = DB::count('processos', "status='em_andamento' AND data_prazo BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)");

// Recent items
$recentChamados = DB::all(
    "SELECT c.*, f.nome as filial_nome, u.nome as atendente_nome
     FROM chamados c
     LEFT JOIN filiais f ON c.filial_id = f.id
     LEFT JOIN users u ON c.atendente_id = u.id
     ORDER BY c.created_at DESC LIMIT 5"
);

$recentTarefas = DB::all(
    "SELECT t.*, u.nome as resp_nome
     FROM tarefas t
     LEFT JOIN users u ON t.responsavel_id = u.id
     WHERE t.responsavel_id=? OR t.criado_por=?
     ORDER BY t.updated_at DESC LIMIT 5",
    [Auth::id(), Auth::id()]
);

$proximosVencimentos = DB::all(
    "SELECT 'contrato' as tipo, id, titulo, data_fim as data_prazo FROM contratos
     WHERE status='ativo' AND data_fim BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
     UNION
     SELECT 'processo' as tipo, id, titulo, data_prazo FROM processos
     WHERE status='em_andamento' AND data_prazo BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
     ORDER BY data_prazo ASC LIMIT 8"
);

page_start('Dashboard', 'dashboard');
?>

<div class="page-header">
  <div class="page-header-left">
    <h1 class="page-title">Bom dia, <?= htmlspecialchars(explode(' ', Auth::nome())[0]) ?> 👋</h1>
    <p class="page-subtitle"><?= date('l, d \d\e F \d\e Y') ?> — Visão geral do sistema</p>
  </div>
</div>

<!-- Stats -->
<div class="stats-grid">
  <?php statCard('Tarefas Pendentes',  $tarefasPendentes,  '✓',  'brand',  '', url('/pages/tarefas.php')); ?>
  <?php statCard('Chamados Abertos',   $chamadosAbertos,   '🎫', 'blue',   "$chamadosCriticos crítico(s)", url('/pages/chamados.php')); ?>
  <?php statCard('Contratos Vencendo', $contratoVencendo,  '📄', $contratoVencendo > 0 ? 'yellow' : 'green', 'próximos 30 dias', url('/pages/contratos.php')); ?>
  <?php statCard('Equipamentos Ativos',$equipamentosAtivos,'🖥',  'green',  '', url('/pages/ativos.php')); ?>
  <?php statCard('Achados & Perdidos', $achados,           '🔍', 'purple', 'aguardando destinação', url('/pages/achados.php')); ?>
  <?php statCard('Despesas Pendentes', formatMoney((float)($despesasPendentes['total'] ?? 0)), '💰', 'orange', 'aguardando aprovação', url('/pages/financeiro.php')); ?>
  <?php statCard('Processos Vencendo', $processosVencendo, '📋', $processosVencendo > 0 ? 'yellow' : 'green', 'próximos 30 dias', url('/pages/processos.php')); ?>
  <?php statCard('Chamados Críticos',  $chamadosCriticos,  '🚨', $chamadosCriticos > 0 ? 'red' : 'green', 'alta prioridade', url('/pages/chamados.php')); ?>
</div>

<div class="dashboard-grid">

  <!-- Chamados recentes -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">🎫 Chamados Recentes</span>
      <a href="<?= url('/pages/chamados.php') ?>" class="btn btn-ghost btn-sm">Ver todos →</a>
    </div>
    <?php if (empty($recentChamados)): ?>
    <div class="empty-state">
      <div class="empty-icon">🎉</div>
      <div class="empty-title">Nenhum chamado aberto</div>
    </div>
    <?php else: ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead><tr>
          <th>Número</th><th>Título</th><th>Prioridade</th><th>Status</th><th>Filial</th>
        </tr></thead>
        <tbody>
          <?php foreach ($recentChamados as $c): ?>
          <tr>
            <td class="td-mono"><a href="<?= url('/pages/chamados.php?id=' . $c['id']) ?>"><?= htmlspecialchars($c['numero']) ?></a></td>
            <td><strong><?= htmlspecialchars($c['titulo']) ?></strong></td>
            <td><?= prioridadeIcon($c['prioridade']) ?> <?= statusBadge($c['prioridade']) ?></td>
            <td><?= statusBadge($c['status']) ?></td>
            <td><?= htmlspecialchars($c['filial_nome'] ?? '—') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- Minhas tarefas -->
  <div class="card">
    <div class="card-header">
      <span class="card-title">✓ Minhas Tarefas</span>
      <a href="<?= url('/pages/tarefas.php') ?>" class="btn btn-ghost btn-sm">Ver todas →</a>
    </div>
    <?php if (empty($recentTarefas)): ?>
    <div class="empty-state">
      <div class="empty-icon">✅</div>
      <div class="empty-title">Nenhuma tarefa pendente</div>
    </div>
    <?php else: ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead><tr><th>Título</th><th>Prioridade</th><th>Prazo</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recentTarefas as $t): ?>
          <?php $dias = $t['data_fim'] ? diasRestantes($t['data_fim']) : null; ?>
          <tr>
            <td><strong><?= htmlspecialchars($t['titulo']) ?></strong></td>
            <td><?= prioridadeIcon($t['prioridade']) ?></td>
            <td class="td-mono <?= ($dias !== null && $dias < 3) ? 'text-red' : '' ?>">
              <?= $t['data_fim'] ? formatDate($t['data_fim']) : '—' ?>
              <?= ($dias !== null && $dias <= 3 && $dias >= 0) ? "<span class='badge badge-yellow'>$dias d</span>" : '' ?>
              <?= ($dias !== null && $dias < 0) ? "<span class='badge badge-red'>Atrasada</span>" : '' ?>
            </td>
            <td><?= statusBadge($t['status']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

  <!-- Próximos vencimentos -->
  <div class="card dashboard-col-full">
    <div class="card-header">
      <span class="card-title">📅 Próximos Vencimentos (60 dias)</span>
    </div>
    <?php if (empty($proximosVencimentos)): ?>
    <div class="empty-state">
      <div class="empty-icon">🗓</div>
      <div class="empty-title">Nenhum vencimento próximo</div>
    </div>
    <?php else: ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead><tr><th>Tipo</th><th>Título</th><th>Prazo</th><th>Dias restantes</th><th>Ação</th></tr></thead>
        <tbody>
          <?php foreach ($proximosVencimentos as $v):
            $dias = diasRestantes($v['data_prazo']);
            $cls = $dias <= 7 ? 'badge-red' : ($dias <= 15 ? 'badge-yellow' : 'badge-blue');
            $icon = $v['tipo'] === 'contrato' ? '📄' : '📋';
            $link = $v['tipo'] === 'contrato' ? url('/pages/contratos.php') : url('/pages/processos.php');
          ?>
          <tr>
            <td><?= $icon ?> <span class="badge badge-gray"><?= ucfirst($v['tipo']) ?></span></td>
            <td><strong><?= htmlspecialchars($v['titulo']) ?></strong></td>
            <td class="td-mono"><?= formatDate($v['data_prazo']) ?></td>
            <td><span class="badge <?= $cls ?>"><?= $dias ?> dia(s)</span></td>
            <td><a href="<?= $link ?>" class="btn btn-xs btn-outline">Ver →</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

</div>

<?php page_end(); ?>
