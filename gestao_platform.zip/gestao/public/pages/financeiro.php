<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
require_once __DIR__ . '/../../includes/comentarios.php';
Auth::start(); Auth::require();

$tab = $_GET['tab'] ?? 'despesas';
$id  = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST; $a = $p['_action'] ?? '';

    if ($a === 'salvar_despesa') {
        $campos = ['titulo','descricao','categoria','valor','data','status','filial_id',
                   'fornecedor_id','data_pagamento','numero_nf','centro_custo','obs'];
        if ($p['id']??0) {
            $sets = implode(',', array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $vals[] = $p['id'];
            DB::run("UPDATE despesas SET $sets WHERE id=?", $vals);
            setFlash('Despesa atualizada!','success');
        } else {
            $p['solicitante_id'] = Auth::id();
            array_push($campos,'solicitante_id');
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            DB::insert("INSERT INTO despesas (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            setFlash('Despesa registrada!','success');
        }
        header('Location: '.url('/pages/financeiro.php?tab=despesas')); exit;
    }
    if ($a === 'aprovar') {
        DB::run("UPDATE despesas SET status='aprovada',aprovador_id=?,data_aprovacao=NOW() WHERE id=?", [Auth::id(),$p['id']]);
        setFlash('Despesa aprovada!','success');
        header('Location: '.url('/pages/financeiro.php?tab=despesas')); exit;
    }
    if ($a === 'rejeitar') {
        DB::run("UPDATE despesas SET status='rejeitada',aprovador_id=? WHERE id=?", [Auth::id(),$p['id']]);
        setFlash('Despesa rejeitada.','success');
        header('Location: '.url('/pages/financeiro.php?tab=despesas')); exit;
    }
    if ($a === 'salvar_nf') {
        $campos = ['numero','serie','fornecedor_id','valor','data_emissao','data_vencimento','status','despesa_id','obs'];
        if ($p['id']??0) {
            $sets = implode(',', array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $vals[] = $p['id'];
            DB::run("UPDATE notas_fiscais SET $sets WHERE id=?", $vals);
        } else {
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            DB::insert("INSERT INTO notas_fiscais (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
        }
        setFlash('NF salva!','success');
        header('Location: '.url('/pages/financeiro.php?tab=notas')); exit;
    }
}

$editDespesa = $id && $tab==='despesas' ? DB::one("SELECT * FROM despesas WHERE id=?",[$id]) : null;
$editNF      = $id && $tab==='notas'    ? DB::one("SELECT * FROM notas_fiscais WHERE id=?",[$id]) : null;

$despesas = DB::all("SELECT d.*,f.nome as filial_nome,fo.razao_social as forn_nome,u.nome as sol_nome
    FROM despesas d LEFT JOIN filiais f ON d.filial_id=f.id
    LEFT JOIN fornecedores fo ON d.fornecedor_id=fo.id
    LEFT JOIN users u ON d.solicitante_id=u.id ORDER BY d.created_at DESC");

$notas = DB::all("SELECT n.*,fo.razao_social as forn_nome FROM notas_fiscais n
    LEFT JOIN fornecedores fo ON n.fornecedor_id=fo.id ORDER BY n.data_emissao DESC");

$totalPendente = DB::one("SELECT SUM(valor) as t FROM despesas WHERE status='pendente'")['t']??0;
$totalAprovado = DB::one("SELECT SUM(valor) as t FROM despesas WHERE status='aprovada'")['t']??0;
$totalPago     = DB::one("SELECT SUM(valor) as t FROM despesas WHERE status='paga' AND MONTH(data_pagamento)=MONTH(NOW())")['t']??0;
$nfVencendo    = DB::count('notas_fiscais',"status='pendente' AND data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY)");

page_start('Financeiro','financeiro');
pageHeader('💰 Financeiro','Controle de despesas, notas fiscais e aprovações');
flashMessage();
?>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
  <?php
  statCard('Pendente Aprovação', formatMoney((float)$totalPendente),'⏳','yellow');
  statCard('Aprovadas',          formatMoney((float)$totalAprovado),'✅','blue');
  statCard('Pago este mês',      formatMoney((float)$totalPago),   '💳','green');
  statCard('NF vencendo (7d)',   $nfVencendo,                      '📄',$nfVencendo>0?'red':'green');
  ?>
</div>

<div class="tabs">
  <button class="tab-btn <?= $tab==='despesas'?'active':'' ?>" onclick="window.location='<?= url('/pages/financeiro.php?tab=despesas') ?>'">💸 Despesas</button>
  <button class="tab-btn <?= $tab==='notas'?'active':'' ?>" onclick="window.location='<?= url('/pages/financeiro.php?tab=notas') ?>'">📄 Notas Fiscais</button>
</div>

<?php if ($tab === 'despesas'): ?>
<div class="page-header-actions" style="margin-bottom:12px">
  <button class="btn btn-primary" onclick="openModal('modalDespesa')">+ Nova Despesa</button>
</div>
<div class="card">
  <div class="table-wrapper"><table class="data-table">
    <thead><tr><th>Título</th><th>Categoria</th><th>Valor</th><th>Data</th><th>Filial</th><th>Fornecedor</th><th>Status</th><th>Solicitante</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($despesas as $d): ?>
    <tr>
      <td><strong><?= htmlspecialchars($d['titulo']) ?></strong><?= $d['centro_custo']?"<br><span class='text-xs text-muted'>{$d['centro_custo']}</span>":'' ?></td>
      <td><?= ucfirst(str_replace('_',' ',$d['categoria'])) ?></td>
      <td class="fw-bold"><?= formatMoney($d['valor']) ?></td>
      <td class="td-mono"><?= formatDate($d['data']) ?></td>
      <td><?= htmlspecialchars($d['filial_nome']??'—') ?></td>
      <td><?= htmlspecialchars($d['forn_nome']??'—') ?></td>
      <td><?= statusBadge($d['status']) ?></td>
      <td><?= htmlspecialchars($d['sol_nome']??'—') ?></td>
      <td class="td-actions">
        <a href="<?= url('/pages/financeiro.php?tab=despesas&id='.$d['id']) ?>" class="btn btn-xs btn-outline">✏</a>
        <?php if ($d['status']==='pendente' && Auth::isGestor()): ?>
        <form method="POST" style="display:inline">
          <input type="hidden" name="_action" value="aprovar"><input type="hidden" name="id" value="<?= $d['id'] ?>">
          <button class="btn btn-xs btn-success" title="Aprovar">✓</button>
        </form>
        <form method="POST" style="display:inline">
          <input type="hidden" name="_action" value="rejeitar"><input type="hidden" name="id" value="<?= $d['id'] ?>">
          <button class="btn btn-xs btn-danger" title="Rejeitar">✕</button>
        </form>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<?php if ($editDespesa): ?>
<div class="card mt-2">
  <div class="card-header"><span class="card-title">✏ Editando Despesa</span><a href="<?= url('/pages/financeiro.php?tab=despesas') ?>" class="btn btn-ghost btn-sm">✕</a></div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="salvar_despesa"><input type="hidden" name="id" value="<?= $editDespesa['id'] ?>">
      <?php renderFormDespesa($editDespesa); ?>
      <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar</button></div>
    </form>
  </div>
</div>
<?php renderComentarios('despesa', $editDespesa['id']); ?>
<?php endif; ?>

<div class="modal-overlay" id="modalDespesa">
  <div class="modal modal-lg"><div class="modal-header"><span class="modal-title">💸 Nova Despesa</span><button class="modal-close" onclick="closeModal('modalDespesa')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="salvar_despesa">
  <div class="modal-body"><?php renderFormDespesa(); ?></div>
  <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalDespesa')">Cancelar</button><button type="submit" class="btn btn-primary">Registrar</button></div>
  </form></div>
</div>

<?php elseif ($tab === 'notas'): ?>
<div class="page-header-actions" style="margin-bottom:12px">
  <button class="btn btn-primary" onclick="openModal('modalNF')">+ Nova NF</button>
</div>
<div class="card">
  <div class="table-wrapper"><table class="data-table">
    <thead><tr><th>Número</th><th>Fornecedor</th><th>Valor</th><th>Emissão</th><th>Vencimento</th><th>Status</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($notas as $n):
      $venc = $n['data_vencimento'] && $n['data_vencimento'] < date('Y-m-d') && $n['status'] === 'pendente';
    ?>
    <tr>
      <td class="td-mono"><strong><?= htmlspecialchars($n['numero']) ?></strong><?= $n['serie']?" / {$n['serie']}":'' ?></td>
      <td><?= htmlspecialchars($n['forn_nome']??'—') ?></td>
      <td class="fw-bold"><?= formatMoney($n['valor']) ?></td>
      <td class="td-mono"><?= formatDate($n['data_emissao']) ?></td>
      <td class="td-mono <?= $venc?'text-red':'' ?>"><?= $n['data_vencimento']?formatDate($n['data_vencimento']):'—' ?><?= $venc?" <span class='badge badge-red'>Vencida</span>":'' ?></td>
      <td><?= statusBadge($n['status']) ?></td>
      <td><a href="<?= url('/pages/financeiro.php?tab=notas&id='.$n['id']) ?>" class="btn btn-xs btn-outline">✏</a></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<?php if ($editNF): ?>
<div class="card mt-2">
  <div class="card-header"><span class="card-title">✏ Editando NF <?= htmlspecialchars($editNF['numero']) ?></span><a href="<?= url('/pages/financeiro.php?tab=notas') ?>" class="btn btn-ghost btn-sm">✕</a></div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="salvar_nf"><input type="hidden" name="id" value="<?= $editNF['id'] ?>">
      <?php renderFormNF($editNF); ?>
      <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar</button></div>
    </form>
  </div>
</div>
<?php renderComentarios('nota_fiscal', $editNF['id']); ?>
<?php endif; ?>

<div class="modal-overlay" id="modalNF">
  <div class="modal modal-lg"><div class="modal-header"><span class="modal-title">📄 Nova Nota Fiscal</span><button class="modal-close" onclick="closeModal('modalNF')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="salvar_nf">
  <div class="modal-body"><?php renderFormNF(); ?></div>
  <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalNF')">Cancelar</button><button type="submit" class="btn btn-primary">Salvar</button></div>
  </form></div>
</div>
<?php endif; ?>

<?php
function renderFormDespesa(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
  <div class="form-group" style="grid-column:span 2"><label class="form-label">Título *</label><input type="text" name="titulo" class="form-input" required value="<?= htmlspecialchars($d['titulo']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Categoria</label>
    <select name="categoria" class="form-select">
      <?= selectOptions([['v'=>'manutencao','l'=>'Manutenção'],['v'=>'fornecedor','l'=>'Fornecedor'],['v'=>'aluguel','l'=>'Aluguel'],['v'=>'utilidades','l'=>'Utilidades'],['v'=>'ti','l'=>'TI'],['v'=>'administrativo','l'=>'Administrativo'],['v'=>'outros','l'=>'Outros']],'v','l',$d['categoria']??'outros') ?>
    </select></div>
  <div class="form-group"><label class="form-label">Valor *</label><input type="number" name="valor" class="form-input" step="0.01" required value="<?= $d['valor']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Data *</label><input type="date" name="data" class="form-input" required value="<?= $d['data']??date('Y-m-d') ?>"></div>
  <div class="form-group"><label class="form-label">Status</label>
    <select name="status" class="form-select">
      <?= selectOptions([['v'=>'pendente','l'=>'Pendente'],['v'=>'aprovada','l'=>'Aprovada'],['v'=>'paga','l'=>'Paga'],['v'=>'rejeitada','l'=>'Rejeitada']],'v','l',$d['status']??'pendente') ?>
    </select></div>
  <div class="form-group"><label class="form-label">Data Pagamento</label><input type="date" name="data_pagamento" class="form-input" value="<?= $d['data_pagamento']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Filial</label><select name="filial_id" class="form-select"><?= selectOptions(filiais(),'id','nome',$d['filial_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Fornecedor</label><select name="fornecedor_id" class="form-select"><?= selectOptions(fornecedores(),'id','razao_social',$d['fornecedor_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Nº Nota Fiscal</label><input type="text" name="numero_nf" class="form-input" value="<?= htmlspecialchars($d['numero_nf']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Centro de Custo</label><input type="text" name="centro_custo" class="form-input" value="<?= htmlspecialchars($d['centro_custo']??'') ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Descrição</label><textarea name="descricao" class="form-textarea" rows="2"><?= htmlspecialchars($d['descricao']??'') ?></textarea></div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="2"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }

function renderFormNF(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
  <div class="form-group"><label class="form-label">Número NF *</label><input type="text" name="numero" class="form-input" required value="<?= htmlspecialchars($d['numero']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Série</label><input type="text" name="serie" class="form-input" value="<?= htmlspecialchars($d['serie']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Fornecedor</label><select name="fornecedor_id" class="form-select"><?= selectOptions(fornecedores(),'id','razao_social',$d['fornecedor_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Valor *</label><input type="number" name="valor" class="form-input" step="0.01" required value="<?= $d['valor']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Emissão *</label><input type="date" name="data_emissao" class="form-input" required value="<?= $d['data_emissao']??date('Y-m-d') ?>"></div>
  <div class="form-group"><label class="form-label">Vencimento</label><input type="date" name="data_vencimento" class="form-input" value="<?= $d['data_vencimento']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Status</label>
    <select name="status" class="form-select">
      <?= selectOptions([['v'=>'pendente','l'=>'Pendente'],['v'=>'paga','l'=>'Paga'],['v'=>'cancelada','l'=>'Cancelada'],['v'=>'vencida','l'=>'Vencida']],'v','l',$d['status']??'pendente') ?>
    </select></div>
  <div class="form-group"><label class="form-label">Despesa vinculada</label><input type="number" name="despesa_id" class="form-input" placeholder="ID" value="<?= $d['despesa_id']??'' ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="2"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }
page_end(); ?>
