<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
require_once __DIR__ . '/../../includes/comentarios.php';
Auth::start(); Auth::require();

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST; $a = $p['_action'] ?? '';

    if (in_array($a, ['salvar_forn'])) {
        $campos = ['razao_social','nome_fantasia','cnpj','inscricao_estadual','categoria',
                   'telefone','email','site','contato','banco','agencia','conta','pix',
                   'endereco','bairro','cep','cidade','estado','status','obs'];
        if ($p['id'] ?? 0) {
            $sets = implode(',', array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $vals[] = $p['id'];
            DB::run("UPDATE fornecedores SET $sets WHERE id=?", $vals);
            setFlash('Fornecedor atualizado!','success');
            header('Location: '.url('/pages/fornecedores.php?id='.$p['id'])); exit;
        } else {
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $newId = DB::insert("INSERT INTO fornecedores (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            Log::write('fornecedores','criar','Fornecedor criado');
            setFlash('Fornecedor cadastrado!','success');
            header('Location: '.url('/pages/fornecedores.php?id='.$newId)); exit;
        }
    }
    if ($a === 'salvar_servico') {
        if ($p['servico_id']??0) {
            DB::run("UPDATE fornecedores_servicos SET descricao=?,valor=?,unidade=? WHERE id=?",
                [$p['descricao'],$p['valor']?:null,$p['unidade'],$p['servico_id']]);
        } else {
            DB::insert("INSERT INTO fornecedores_servicos (fornecedor_id,descricao,valor,unidade) VALUES (?,?,?,?)",
                [$p['fornecedor_id'],$p['descricao'],$p['valor']?:null,$p['unidade']]);
        }
        setFlash('Serviço salvo!','success');
        header('Location: '.url('/pages/fornecedores.php?id='.$p['fornecedor_id'].'&tab=servicos')); exit;
    }
    if ($a === 'salvar_avaliacao') {
        DB::insert("INSERT INTO fornecedores_avaliacoes (fornecedor_id,user_id,nota,comentario) VALUES (?,?,?,?)",
            [$p['fornecedor_id'], Auth::id(), $p['nota'], $p['comentario']]);
        // Recalcular média
        $media = DB::one("SELECT AVG(nota) as m FROM fornecedores_avaliacoes WHERE fornecedor_id=?",[$p['fornecedor_id']]);
        DB::run("UPDATE fornecedores SET avaliacao_media=? WHERE id=?", [round($media['m'],2),$p['fornecedor_id']]);
        setFlash('Avaliação registrada!','success');
        header('Location: '.url('/pages/fornecedores.php?id='.$p['fornecedor_id'].'&tab=avaliacoes')); exit;
    }
    if ($a === 'salvar_atendimento') {
        if ($p['atend_id']??0) {
            DB::run("UPDATE atendimentos SET titulo=?,descricao=?,valor=?,data=?,status=?,chamado_id=? WHERE id=?",
                [$p['titulo'],$p['descricao'],$p['valor']?:null,$p['data'],$p['status'],$p['chamado_id']?:null,$p['atend_id']]);
        } else {
            DB::insert("INSERT INTO atendimentos (fornecedor_id,titulo,descricao,valor,data,status,chamado_id) VALUES (?,?,?,?,?,?,?)",
                [$p['fornecedor_id'],$p['titulo'],$p['descricao'],$p['valor']?:null,$p['data'],$p['status'],$p['chamado_id']?:null]);
        }
        setFlash('Atendimento salvo!','success');
        header('Location: '.url('/pages/fornecedores.php?id='.$p['fornecedor_id'].'&tab=atendimentos')); exit;
    }
}

$tab = $_GET['tab'] ?? 'info';
$forn = $id ? DB::one("SELECT * FROM fornecedores WHERE id=?", [$id]) : null;
$lista = DB::all("SELECT *,(SELECT AVG(nota) FROM fornecedores_avaliacoes WHERE fornecedor_id=fornecedores.id) as media FROM fornecedores ORDER BY razao_social");

page_start('Fornecedores','fornecedores');
pageHeader('🏢 Fornecedores','Cadastro e CRM de fornecedores',[
    ['label'=>'+ Novo','href'=>url('/pages/fornecedores.php'),'cls'=>'btn-primary'],
]);
flashMessage();
?>

<div class="dashboard-grid" style="grid-template-columns:300px 1fr">
<!-- Lista lateral -->
<div class="card" style="height:fit-content">
  <div class="card-header"><span class="card-title">Fornecedores</span></div>
  <div style="padding:8px">
    <input type="text" class="filter-input" style="width:100%;margin-bottom:8px" placeholder="Buscar..." oninput="filtrarLista(this.value)">
    <div id="forn-lista">
    <?php foreach ($lista as $f): ?>
    <a href="<?= url('/pages/fornecedores.php?id='.$f['id']) ?>"
       class="fornecedor-item <?= $f['id']==$id?'forn-active':'' ?>">
      <div style="font-weight:600;font-size:.85rem"><?= htmlspecialchars($f['razao_social']) ?></div>
      <div style="font-size:.75rem;color:var(--t3)"><?= htmlspecialchars($f['categoria']??'') ?> · <?= statusBadge($f['status']) ?></div>
      <?php if ($f['media']): ?>
      <div style="font-size:.75rem;color:var(--yellow)">★ <?= number_format($f['media'],1) ?></div>
      <?php endif; ?>
    </a>
    <?php endforeach; ?>
    </div>
  </div>
  <div class="card-footer">
    <a href="<?= url('/pages/fornecedores.php') ?>" class="btn btn-primary btn-sm" style="width:100%;justify-content:center">+ Novo Fornecedor</a>
  </div>
</div>

<!-- Detalhe -->
<div>
<?php if ($forn): ?>
  <!-- Tabs -->
  <div class="tabs">
    <button class="tab-btn <?= $tab==='info'?'active':'' ?>" onclick="goTab('info')">📋 Dados</button>
    <button class="tab-btn <?= $tab==='servicos'?'active':'' ?>" onclick="goTab('servicos')">🛠 Serviços</button>
    <button class="tab-btn <?= $tab==='atendimentos'?'active':'' ?>" onclick="goTab('atendimentos')">📅 Atendimentos</button>
    <button class="tab-btn <?= $tab==='avaliacoes'?'active':'' ?>" onclick="goTab('avaliacoes')">⭐ Avaliações</button>
  </div>

  <?php if ($tab === 'info'): ?>
  <div class="card">
    <div class="card-header">
      <span class="card-title"><?= htmlspecialchars($forn['razao_social']) ?></span>
      <?= statusBadge($forn['status']) ?>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="_action" value="salvar_forn">
        <input type="hidden" name="id" value="<?= $forn['id'] ?>">
        <?php renderFormForn($forn); ?>
        <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar Alterações</button></div>
      </form>
    </div>
  </div>
  <?php renderComentarios('fornecedor', $forn['id']); ?>

  <?php elseif ($tab === 'servicos'):
    $servicos = DB::all("SELECT * FROM fornecedores_servicos WHERE fornecedor_id=? ORDER BY descricao",[$id]);
  ?>
  <div class="card">
    <div class="card-header"><span class="card-title">🛠 Serviços Prestados</span><button class="btn btn-primary btn-sm" onclick="openModal('modalServico')">+ Adicionar</button></div>
    <div class="table-wrapper"><table class="data-table">
      <thead><tr><th>Descrição</th><th>Valor</th><th>Unidade</th><th>Ações</th></tr></thead>
      <tbody>
      <?php foreach ($servicos as $s): ?>
      <tr>
        <td><?= htmlspecialchars($s['descricao']) ?></td>
        <td><?= $s['valor']?formatMoney($s['valor']):'—' ?></td>
        <td><?= htmlspecialchars($s['unidade']??'—') ?></td>
        <td><button class="btn btn-xs btn-outline" onclick="editarServico(<?= htmlspecialchars(json_encode($s)) ?>)">✏</button></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
  <div class="modal-overlay" id="modalServico">
    <div class="modal"><div class="modal-header"><span class="modal-title">Serviço</span><button class="modal-close" onclick="closeModal('modalServico')">✕</button></div>
    <form method="POST"><input type="hidden" name="_action" value="salvar_servico">
    <input type="hidden" name="fornecedor_id" value="<?= $id ?>"><input type="hidden" name="servico_id" id="servicoId">
    <div class="modal-body">
      <div class="form-grid form-grid-3" style="gap:10px">
        <div class="form-group" style="grid-column:span 3"><label class="form-label">Descrição *</label><input type="text" name="descricao" id="servicoDescricao" class="form-input" required></div>
        <div class="form-group"><label class="form-label">Valor</label><input type="number" name="valor" id="servicoValor" class="form-input" step="0.01"></div>
        <div class="form-group"><label class="form-label">Unidade</label><input type="text" name="unidade" id="servicoUnidade" class="form-input" placeholder="hora, m², un..."></div>
      </div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalServico')">Cancelar</button><button type="submit" class="btn btn-primary">Salvar</button></div>
    </form></div>
  </div>
  <script>
  function editarServico(s) {
    document.getElementById('servicoId').value = s.id;
    document.getElementById('servicoDescricao').value = s.descricao;
    document.getElementById('servicoValor').value = s.valor||'';
    document.getElementById('servicoUnidade').value = s.unidade||'';
    openModal('modalServico');
  }
  </script>

  <?php elseif ($tab === 'atendimentos'):
    $atends = DB::all("SELECT * FROM atendimentos WHERE fornecedor_id=? ORDER BY data DESC",[$id]);
  ?>
  <div class="card">
    <div class="card-header"><span class="card-title">📅 Histórico de Atendimentos</span><button class="btn btn-primary btn-sm" onclick="openModal('modalAtend')">+ Registrar</button></div>
    <div class="table-wrapper"><table class="data-table">
      <thead><tr><th>Data</th><th>Título</th><th>Valor</th><th>Status</th><th>Chamado</th></tr></thead>
      <tbody>
      <?php foreach ($atends as $a): ?>
      <tr>
        <td class="td-mono"><?= formatDate($a['data']) ?></td>
        <td><strong><?= htmlspecialchars($a['titulo']??'—') ?></strong><br><span class="text-xs text-muted"><?= htmlspecialchars(substr($a['descricao']??'',0,60)) ?></span></td>
        <td><?= $a['valor']?formatMoney($a['valor']):'—' ?></td>
        <td><?= statusBadge($a['status']) ?></td>
        <td><?= $a['chamado_id']?"#".$a['chamado_id']:'—' ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
  <div class="modal-overlay" id="modalAtend">
    <div class="modal"><div class="modal-header"><span class="modal-title">Registrar Atendimento</span><button class="modal-close" onclick="closeModal('modalAtend')">✕</button></div>
    <form method="POST"><input type="hidden" name="_action" value="salvar_atendimento"><input type="hidden" name="fornecedor_id" value="<?= $id ?>">
    <div class="modal-body"><div class="form-grid form-grid-2" style="gap:10px">
      <div class="form-group" style="grid-column:span 2"><label class="form-label">Título</label><input type="text" name="titulo" class="form-input"></div>
      <div class="form-group"><label class="form-label">Data</label><input type="date" name="data" class="form-input" value="<?= date('Y-m-d') ?>"></div>
      <div class="form-group"><label class="form-label">Valor</label><input type="number" name="valor" class="form-input" step="0.01"></div>
      <div class="form-group"><label class="form-label">Status</label>
        <select name="status" class="form-select"><option value="agendado">Agendado</option><option value="realizado">Realizado</option><option value="cancelado">Cancelado</option></select></div>
      <div class="form-group"><label class="form-label">Chamado ID</label><input type="number" name="chamado_id" class="form-input"></div>
      <div class="form-group" style="grid-column:span 2"><label class="form-label">Descrição</label><textarea name="descricao" class="form-textarea" rows="3"></textarea></div>
    </div></div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalAtend')">Cancelar</button><button type="submit" class="btn btn-primary">Salvar</button></div>
    </form></div>
  </div>

  <?php elseif ($tab === 'avaliacoes'):
    $avals = DB::all("SELECT a.*,u.nome FROM fornecedores_avaliacoes a LEFT JOIN users u ON a.user_id=u.id WHERE a.fornecedor_id=? ORDER BY a.created_at DESC",[$id]);
  ?>
  <div class="card">
    <div class="card-header">
      <span class="card-title">⭐ Avaliações — Média: <?= number_format($forn['avaliacao_media']??0,1) ?>/5</span>
      <button class="btn btn-primary btn-sm" onclick="openModal('modalAval')">+ Avaliar</button>
    </div>
    <div class="card-body">
    <?php foreach ($avals as $av): ?>
    <div style="padding:10px 0;border-bottom:1px solid var(--b1)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
        <strong style="font-size:.85rem"><?= htmlspecialchars($av['nome']??'Anônimo') ?></strong>
        <span style="color:var(--yellow)"><?= str_repeat('★',$av['nota']) . str_repeat('☆',5-$av['nota']) ?></span>
        <span class="text-xs text-muted"><?= formatDate($av['created_at'],true) ?></span>
      </div>
      <?php if ($av['comentario']): ?>
      <p style="font-size:.85rem;color:var(--t2)"><?= nl2br(htmlspecialchars($av['comentario'])) ?></p>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    </div>
  </div>
  <div class="modal-overlay" id="modalAval">
    <div class="modal"><div class="modal-header"><span class="modal-title">Avaliar Fornecedor</span><button class="modal-close" onclick="closeModal('modalAval')">✕</button></div>
    <form method="POST"><input type="hidden" name="_action" value="salvar_avaliacao"><input type="hidden" name="fornecedor_id" value="<?= $id ?>">
    <div class="modal-body">
      <div class="form-group" style="margin-bottom:12px"><label class="form-label">Nota (1 a 5) *</label>
        <select name="nota" class="form-select" required>
          <option value="5">★★★★★ Excelente</option>
          <option value="4">★★★★☆ Bom</option>
          <option value="3">★★★☆☆ Regular</option>
          <option value="2">★★☆☆☆ Ruim</option>
          <option value="1">★☆☆☆☆ Péssimo</option>
        </select></div>
      <div class="form-group"><label class="form-label">Comentário</label><textarea name="comentario" class="form-textarea" rows="3"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalAval')">Cancelar</button><button type="submit" class="btn btn-primary">Enviar</button></div>
    </form></div>
  </div>
  <?php endif; ?>

<?php else: ?>
<!-- Formulário novo fornecedor -->
<div class="card">
  <div class="card-header"><span class="card-title">+ Novo Fornecedor</span></div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="salvar_forn">
      <?php renderFormForn(); ?>
      <div class="btn-row mt-2"><button class="btn btn-primary">💾 Cadastrar</button></div>
    </form>
  </div>
</div>
<?php endif; ?>
</div><!-- /detalhe -->
</div><!-- /grid -->

<style>
.fornecedor-item { display:block;padding:10px 12px;border-radius:7px;color:var(--t1);margin-bottom:3px;transition:background .12s; }
.fornecedor-item:hover { background:var(--b1); }
.forn-active { background:var(--brand-dim);color:var(--brand-lt); }
</style>
<script>
function goTab(t) { window.location='<?= url('/pages/fornecedores.php') ?>?id=<?= $id ?>&tab='+t; }
function filtrarLista(q) {
  q = q.toLowerCase();
  document.querySelectorAll('.fornecedor-item').forEach(el => {
    el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
</script>

<?php
function renderFormForn(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
  <div class="form-group" style="grid-column:span 2"><label class="form-label">Razão Social *</label><input type="text" name="razao_social" class="form-input" required value="<?= htmlspecialchars($d['razao_social']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Nome Fantasia</label><input type="text" name="nome_fantasia" class="form-input" value="<?= htmlspecialchars($d['nome_fantasia']??'') ?>"></div>
  <div class="form-group"><label class="form-label">CNPJ</label><input type="text" name="cnpj" class="form-input" placeholder="00.000.000/0000-00" value="<?= htmlspecialchars($d['cnpj']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Inscrição Estadual</label><input type="text" name="inscricao_estadual" class="form-input" value="<?= htmlspecialchars($d['inscricao_estadual']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Categoria</label><input type="text" name="categoria" class="form-input" placeholder="TI, Limpeza, Segurança..." value="<?= htmlspecialchars($d['categoria']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Telefone</label><input type="text" name="telefone" class="form-input" value="<?= htmlspecialchars($d['telefone']??'') ?>"></div>
  <div class="form-group"><label class="form-label">E-mail</label><input type="email" name="email" class="form-input" value="<?= htmlspecialchars($d['email']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Site</label><input type="text" name="site" class="form-input" value="<?= htmlspecialchars($d['site']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Contato</label><input type="text" name="contato" class="form-input" value="<?= htmlspecialchars($d['contato']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Banco</label><input type="text" name="banco" class="form-input" value="<?= htmlspecialchars($d['banco']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Agência</label><input type="text" name="agencia" class="form-input" value="<?= htmlspecialchars($d['agencia']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Conta</label><input type="text" name="conta" class="form-input" value="<?= htmlspecialchars($d['conta']??'') ?>"></div>
  <div class="form-group"><label class="form-label">PIX</label><input type="text" name="pix" class="form-input" value="<?= htmlspecialchars($d['pix']??'') ?>"></div>
  <div class="form-group" style="grid-column:span 2"><label class="form-label">Endereço</label><input type="text" name="endereco" class="form-input" value="<?= htmlspecialchars($d['endereco']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Bairro</label><input type="text" name="bairro" class="form-input" value="<?= htmlspecialchars($d['bairro']??'') ?>"></div>
  <div class="form-group"><label class="form-label">CEP</label><input type="text" name="cep" class="form-input" value="<?= htmlspecialchars($d['cep']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Cidade</label><input type="text" name="cidade" class="form-input" value="<?= htmlspecialchars($d['cidade']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Estado</label><input type="text" name="estado" class="form-input" maxlength="2" value="<?= htmlspecialchars($d['estado']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Status</label>
    <select name="status" class="form-select">
      <option value="ativo" <?= ($d['status']??'ativo')==='ativo'?'selected':'' ?>>Ativo</option>
      <option value="inativo" <?= ($d['status']??'')==='inativo'?'selected':'' ?>>Inativo</option>
      <option value="bloqueado" <?= ($d['status']??'')==='bloqueado'?'selected':'' ?>>Bloqueado</option>
    </select></div>
</div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="3"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }

page_end(); ?>
