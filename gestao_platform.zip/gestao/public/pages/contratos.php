<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
require_once __DIR__ . '/../../includes/comentarios.php';
Auth::start(); Auth::require();

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST; $a = $p['_action'] ?? '';
    if ($a === 'salvar') {
        $campos = ['numero','titulo','tipo','filial_id','fornecedor_id','responsavel_id',
                   'valor_mensal','valor_total','indice_reajuste','data_reajuste',
                   'data_inicio','data_fim','status','alerta_dias','obs','clausulas'];
        if ($p['id']??0) {
            $sets = implode(',', array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $vals[] = $p['id'];
            DB::run("UPDATE contratos SET $sets WHERE id=?", $vals);
            setFlash('Contrato atualizado!','success');
            header('Location: '.url('/pages/contratos.php?id='.$p['id'])); exit;
        } else {
            if (!($p['numero']??'')) $p['numero'] = gerarNumero('CTR','contratos','numero');
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $newId = DB::insert("INSERT INTO contratos (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            Log::write('contratos','criar','Contrato '.$p['numero'].' criado');
            setFlash('Contrato cadastrado!','success');
            header('Location: '.url('/pages/contratos.php?id='.$newId)); exit;
        }
    }
    if ($a === 'excluir') {
        DB::run('DELETE FROM contratos WHERE id=?',[$p['id']]);
        setFlash('Contrato excluído!','success');
        header('Location: '.url('/pages/contratos.php')); exit;
    }
}

$edit    = $id ? DB::one("SELECT c.*,f.nome as filial_nome,fo.razao_social as forn_nome FROM contratos c LEFT JOIN filiais f ON c.filial_id=f.id LEFT JOIN fornecedores fo ON c.fornecedor_id=fo.id WHERE c.id=?",[$id]) : null;
$filter  = $_GET['status'] ?? '';
$where   = $filter ? "WHERE status=?" : "WHERE 1";
$params  = $filter ? [$filter] : [];
$lista   = DB::all("SELECT c.*,f.nome as filial_nome,fo.razao_social as forn_nome FROM contratos c LEFT JOIN filiais f ON c.filial_id=f.id LEFT JOIN fornecedores fo ON c.fornecedor_id=fo.id $where ORDER BY c.data_fim ASC", $params);

// Atualizar status automaticamente
DB::run("UPDATE contratos SET status='vencido' WHERE status='ativo' AND data_fim < CURDATE()");
DB::run("UPDATE contratos SET status='vencendo' WHERE status='ativo' AND data_fim BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL alerta_dias DAY)");

page_start('Contratos','contratos');
pageHeader('📄 Contratos','Gestão de contratos de aluguel, serviços e fornecedores',[
    ['label'=>'+ Novo Contrato','href'=>'#','onclick'=>"openModal('modalContrato')",'cls'=>'btn-primary'],
]);
flashMessage();
?>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
<?php
statCard('Ativos',   DB::count('contratos',"status='ativo'"),   '✅','green');
statCard('Vencendo', DB::count('contratos',"status='vencendo'"),'⚠','yellow');
statCard('Vencidos', DB::count('contratos',"status='vencido'"), '❌','red');
$val = DB::one("SELECT SUM(valor_mensal) as t FROM contratos WHERE status IN ('ativo','vencendo')")['t']??0;
statCard('Custo Mensal Total', formatMoney((float)$val),'💰','blue');
?>
</div>

<!-- Filtros -->
<div class="filters-bar" style="margin-bottom:12px">
  <?php foreach ([''=>'Todos','ativo'=>'Ativos','vencendo'=>'Vencendo','vencido'=>'Vencidos','encerrado'=>'Encerrados'] as $v=>$l): ?>
  <a href="<?= url('/pages/contratos.php?status='.$v) ?>" class="btn btn-sm <?= $filter===$v?'btn-primary':'btn-outline' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="table-wrapper"><table class="data-table">
    <thead><tr><th>Número</th><th>Título</th><th>Tipo</th><th>Filial</th><th>Fornecedor</th><th>Valor/Mês</th><th>Início</th><th>Vencimento</th><th>Status</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($lista as $c):
      $dias = $c['data_fim'] ? diasRestantes($c['data_fim']) : null;
    ?>
    <tr>
      <td class="td-mono"><?= htmlspecialchars($c['numero']) ?></td>
      <td><strong><?= htmlspecialchars($c['titulo']) ?></strong></td>
      <td><?= ucfirst($c['tipo']) ?></td>
      <td><?= htmlspecialchars($c['filial_nome']??'—') ?></td>
      <td><?= htmlspecialchars($c['forn_nome']??'—') ?></td>
      <td><?= $c['valor_mensal']?formatMoney($c['valor_mensal']):'—' ?></td>
      <td class="td-mono"><?= $c['data_inicio']?formatDate($c['data_inicio']):'—' ?></td>
      <td class="td-mono <?= $dias!==null&&$dias<=30?'text-yellow':($dias!==null&&$dias<0?'text-red':'') ?>">
        <?= $c['data_fim']?formatDate($c['data_fim']):'—' ?>
        <?= $dias!==null&&$dias>=0&&$dias<=30?"<span class='badge badge-yellow'>{$dias}d</span>":'' ?>
        <?= $dias!==null&&$dias<0?"<span class='badge badge-red'>Vencido</span>":'' ?>
      </td>
      <td><?= statusBadge($c['status']) ?></td>
      <td class="td-actions">
        <a href="<?= url('/pages/contratos.php?id='.$c['id']) ?>" class="btn btn-xs btn-outline">Ver</a>
        <form method="POST" style="display:inline" onsubmit="return confirm('Excluir?')">
          <input type="hidden" name="_action" value="excluir"><input type="hidden" name="id" value="<?= $c['id'] ?>">
          <button class="btn btn-xs btn-danger">✕</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<!-- Detalhe / Edição -->
<?php if ($edit): ?>
<div class="card mt-2">
  <div class="card-header">
    <span class="card-title">📄 <?= htmlspecialchars($edit['numero']) ?> — <?= htmlspecialchars($edit['titulo']) ?></span>
    <?= statusBadge($edit['status']) ?>
    <a href="<?= url('/pages/contratos.php') ?>" class="btn btn-ghost btn-sm" style="margin-left:auto">← Voltar</a>
  </div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="salvar"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
      <?php renderFormContrato($edit); ?>
      <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar Alterações</button></div>
    </form>
  </div>
</div>
<?php renderComentarios('contrato', $edit['id']); ?>
<?php endif; ?>

<!-- Modal novo -->
<div class="modal-overlay" id="modalContrato">
  <div class="modal modal-lg"><div class="modal-header"><span class="modal-title">📄 Novo Contrato</span><button class="modal-close" onclick="closeModal('modalContrato')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="salvar">
  <div class="modal-body"><?php renderFormContrato(); ?></div>
  <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalContrato')">Cancelar</button><button type="submit" class="btn btn-primary">Cadastrar</button></div>
  </form></div>
</div>

<?php
function renderFormContrato(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
  <div class="form-group" style="grid-column:span 2"><label class="form-label">Título *</label><input type="text" name="titulo" class="form-input" required value="<?= htmlspecialchars($d['titulo']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Número</label><input type="text" name="numero" class="form-input" placeholder="Auto" value="<?= htmlspecialchars($d['numero']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Tipo</label>
    <select name="tipo" class="form-select"><?= selectOptions([['v'=>'aluguel','l'=>'Aluguel'],['v'=>'servico','l'=>'Serviço'],['v'=>'manutencao','l'=>'Manutenção'],['v'=>'fornecimento','l'=>'Fornecimento'],['v'=>'outros','l'=>'Outros']],'v','l',$d['tipo']??'outros') ?></select></div>
  <div class="form-group"><label class="form-label">Filial</label><select name="filial_id" class="form-select"><?= selectOptions(filiais(),'id','nome',$d['filial_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Fornecedor</label><select name="fornecedor_id" class="form-select"><?= selectOptions(fornecedores(),'id','razao_social',$d['fornecedor_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Responsável</label><select name="responsavel_id" class="form-select"><?= selectOptions(users(),'id','nome',$d['responsavel_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Valor Mensal</label><input type="number" name="valor_mensal" class="form-input" step="0.01" value="<?= $d['valor_mensal']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Valor Total</label><input type="number" name="valor_total" class="form-input" step="0.01" value="<?= $d['valor_total']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Índice Reajuste</label><input type="text" name="indice_reajuste" class="form-input" placeholder="IGPM, IPCA..." value="<?= htmlspecialchars($d['indice_reajuste']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Data Reajuste</label><input type="date" name="data_reajuste" class="form-input" value="<?= $d['data_reajuste']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Início</label><input type="date" name="data_inicio" class="form-input" value="<?= $d['data_inicio']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Vencimento</label><input type="date" name="data_fim" class="form-input" value="<?= $d['data_fim']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Status</label>
    <select name="status" class="form-select"><?= selectOptions([['v'=>'ativo','l'=>'Ativo'],['v'=>'vencendo','l'=>'Vencendo'],['v'=>'vencido','l'=>'Vencido'],['v'=>'encerrado','l'=>'Encerrado'],['v'=>'cancelado','l'=>'Cancelado']],'v','l',$d['status']??'ativo') ?></select></div>
  <div class="form-group"><label class="form-label">Alertar (dias antes)</label><input type="number" name="alerta_dias" class="form-input" value="<?= $d['alerta_dias']??30 ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="2"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<div class="form-group mt-1"><label class="form-label">Cláusulas / Resumo do Contrato</label><textarea name="clausulas" class="form-textarea" rows="4"><?= htmlspecialchars($d['clausulas']??'') ?></textarea></div>
<?php }
page_end(); ?>
