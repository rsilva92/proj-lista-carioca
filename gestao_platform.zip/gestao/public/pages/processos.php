<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
require_once __DIR__ . '/../../includes/comentarios.php';
Auth::start(); Auth::require();

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST; $a = $p['_action'] ?? '';
    if ($a === 'salvar') {
        $campos = ['titulo','tipo','orgao','contato_orgao','numero_processo','descricao',
                   'status','prioridade','filial_id','responsavel_id','data_inicio',
                   'data_prazo','data_conclusao','alerta_dias','custo','obs'];
        if ($p['id']??0) {
            $sets = implode(',', array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $vals[] = $p['id'];
            DB::run("UPDATE processos SET $sets WHERE id=?", $vals);
            setFlash('Processo atualizado!','success');
            header('Location: '.url('/pages/processos.php?id='.$p['id'])); exit;
        } else {
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $newId = DB::insert("INSERT INTO processos (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            Log::write('processos','criar','Processo criado');
            setFlash('Processo cadastrado!','success');
            header('Location: '.url('/pages/processos.php?id='.$newId)); exit;
        }
    }
}

$edit  = $id ? DB::one("SELECT p.*,f.nome as filial_nome,u.nome as resp_nome FROM processos p LEFT JOIN filiais f ON p.filial_id=f.id LEFT JOIN users u ON p.responsavel_id=u.id WHERE p.id=?",[$id]) : null;
$lista = DB::all("SELECT p.*,f.nome as filial_nome,u.nome as resp_nome FROM processos p LEFT JOIN filiais f ON p.filial_id=f.id LEFT JOIN users u ON p.responsavel_id=u.id ORDER BY p.data_prazo ASC");

page_start('Processos Adm.','processos');
pageHeader('📋 Processos Administrativos','Prefeitura, licenças e documentações',[
    ['label'=>'+ Novo Processo','href'=>'#','onclick'=>"openModal('modalProc')",'cls'=>'btn-primary'],
]);
flashMessage();
?>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
<?php
statCard('Em Andamento',DB::count('processos',"status='em_andamento'"),'⚙','blue');
statCard('Pendentes',   DB::count('processos',"status='pendente'"),    '⏳','yellow');
statCard('Vencendo',    DB::count('processos',"status='em_andamento' AND data_prazo BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)"),'⚠','orange');
statCard('Concluídos',  DB::count('processos',"status='concluido'"),   '✅','green');
?>
</div>

<div class="card">
  <div class="table-wrapper"><table class="data-table">
    <thead><tr><th>Título</th><th>Tipo</th><th>Órgão</th><th>Nº Processo</th><th>Filial</th><th>Prioridade</th><th>Prazo</th><th>Status</th><th>Responsável</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($lista as $p):
      $dias = $p['data_prazo'] ? diasRestantes($p['data_prazo']) : null;
      $atrasado = $dias !== null && $dias < 0 && $p['status'] !== 'concluido';
    ?>
    <tr>
      <td><strong><?= htmlspecialchars($p['titulo']) ?></strong></td>
      <td><?= ucfirst($p['tipo']) ?></td>
      <td><?= htmlspecialchars($p['orgao']??'—') ?></td>
      <td class="td-mono"><?= htmlspecialchars($p['numero_processo']??'—') ?></td>
      <td><?= htmlspecialchars($p['filial_nome']??'—') ?></td>
      <td><?= prioridadeIcon($p['prioridade']??'media') ?></td>
      <td class="td-mono <?= $atrasado?'text-red':'' ?>">
        <?= $p['data_prazo']?formatDate($p['data_prazo']):'—' ?>
        <?= $atrasado?"<span class='badge badge-red'>Atrasado</span>":'' ?>
        <?= $dias!==null&&$dias>=0&&$dias<=7?"<span class='badge badge-yellow'>{$dias}d</span>":'' ?>
      </td>
      <td><?= statusBadge($p['status']) ?></td>
      <td><?= htmlspecialchars($p['resp_nome']??'—') ?></td>
      <td><a href="<?= url('/pages/processos.php?id='.$p['id']) ?>" class="btn btn-xs btn-outline">Ver/Editar</a></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<?php if ($edit): ?>
<div class="card mt-2">
  <div class="card-header">
    <span class="card-title">📋 <?= htmlspecialchars($edit['titulo']) ?></span>
    <?= statusBadge($edit['status']) ?> <?= prioridadeIcon($edit['prioridade']??'media') ?>
    <a href="<?= url('/pages/processos.php') ?>" class="btn btn-ghost btn-sm" style="margin-left:auto">← Voltar</a>
  </div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="salvar"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
      <?php renderFormProcesso($edit); ?>
      <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar Alterações</button></div>
    </form>
  </div>
</div>
<?php renderComentarios('processo', $edit['id']); ?>
<?php endif; ?>

<div class="modal-overlay" id="modalProc">
  <div class="modal modal-lg"><div class="modal-header"><span class="modal-title">📋 Novo Processo</span><button class="modal-close" onclick="closeModal('modalProc')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="salvar">
  <div class="modal-body"><?php renderFormProcesso(); ?></div>
  <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalProc')">Cancelar</button><button type="submit" class="btn btn-primary">Cadastrar</button></div>
  </form></div>
</div>

<?php
function renderFormProcesso(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
  <div class="form-group" style="grid-column:span 2"><label class="form-label">Título *</label><input type="text" name="titulo" class="form-input" required value="<?= htmlspecialchars($d['titulo']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Tipo</label>
    <select name="tipo" class="form-select"><?= selectOptions([['v'=>'prefeitura','l'=>'Prefeitura'],['v'=>'licenca','l'=>'Licença'],['v'=>'documentacao','l'=>'Documentação'],['v'=>'outros','l'=>'Outros']],'v','l',$d['tipo']??'outros') ?></select></div>
  <div class="form-group"><label class="form-label">Órgão</label><input type="text" name="orgao" class="form-input" placeholder="Prefeitura, AGEVISA..." value="<?= htmlspecialchars($d['orgao']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Contato no Órgão</label><input type="text" name="contato_orgao" class="form-input" value="<?= htmlspecialchars($d['contato_orgao']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Número do Processo</label><input type="text" name="numero_processo" class="form-input" value="<?= htmlspecialchars($d['numero_processo']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Status</label>
    <select name="status" class="form-select"><?= selectOptions([['v'=>'pendente','l'=>'Pendente'],['v'=>'em_andamento','l'=>'Em Andamento'],['v'=>'concluido','l'=>'Concluído'],['v'=>'vencido','l'=>'Vencido']],'v','l',$d['status']??'em_andamento') ?></select></div>
  <div class="form-group"><label class="form-label">Prioridade</label>
    <select name="prioridade" class="form-select"><?= selectOptions([['v'=>'baixa','l'=>'🟢 Baixa'],['v'=>'media','l'=>'🟡 Média'],['v'=>'alta','l'=>'🟠 Alta'],['v'=>'urgente','l'=>'🔴 Urgente']],'v','l',$d['prioridade']??'media') ?></select></div>
  <div class="form-group"><label class="form-label">Filial</label><select name="filial_id" class="form-select"><?= selectOptions(filiais(),'id','nome',$d['filial_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Responsável</label><select name="responsavel_id" class="form-select"><?= selectOptions(users(),'id','nome',$d['responsavel_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Início</label><input type="date" name="data_inicio" class="form-input" value="<?= $d['data_inicio']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Prazo</label><input type="date" name="data_prazo" class="form-input" value="<?= $d['data_prazo']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Conclusão</label><input type="date" name="data_conclusao" class="form-input" value="<?= $d['data_conclusao']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Custo (R$)</label><input type="number" name="custo" class="form-input" step="0.01" value="<?= $d['custo']??'' ?>"></div>
  <div class="form-group"><label class="form-label">Alertar (dias antes)</label><input type="number" name="alerta_dias" class="form-input" value="<?= $d['alerta_dias']??30 ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Descrição / Detalhes</label><textarea name="descricao" class="form-textarea" rows="3"><?= htmlspecialchars($d['descricao']??'') ?></textarea></div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="2"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }
page_end(); ?>
