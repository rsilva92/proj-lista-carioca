<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
require_once __DIR__ . '/../../includes/comentarios.php';
Auth::start(); Auth::require();

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST; $a = $p['_action'] ?? '';
    if ($a === 'salvar') {
        $campos = ['titulo','descricao','cor','marca','categoria','filial_id','local_encontrado',
                   'data_encontrado','encontrado_por','status','proprietario','cpf_proprietario',
                   'data_devolucao','destinacao','obs_destinacao'];
        if ($p['id']??0) {
            $sets = implode(',', array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $vals[] = $p['id'];
            DB::run("UPDATE achados_perdidos SET $sets WHERE id=?", $vals);
            setFlash('Registro atualizado!','success');
            header('Location: '.url('/pages/achados.php?id='.$p['id'])); exit;
        } else {
            $p['registrado_por'] = Auth::id();
            array_push($campos,'registrado_por');
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            $newId = DB::insert("INSERT INTO achados_perdidos (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            Log::write('achados','criar','Item registrado');
            setFlash('Item registrado!','success');
            header('Location: '.url('/pages/achados.php?id='.$newId)); exit;
        }
    }
    if ($a === 'destinacao') {
        DB::run("UPDATE achados_perdidos SET status=?,destinacao=?,obs_destinacao=?,data_devolucao=? WHERE id=?",
            [$p['status'],$p['destinacao'],$p['obs'],$p['data']?:null,$p['id']]);
        setFlash('Destinação registrada!','success');
        header('Location: '.url('/pages/achados.php?id='.$p['id'])); exit;
    }
}

$filter = $_GET['status'] ?? '';
$where  = $filter ? "WHERE a.status=?" : "WHERE 1";
$params = $filter ? [$filter] : [];
$lista  = DB::all("SELECT a.*,f.nome as filial_nome,u.nome as reg_nome FROM achados_perdidos a LEFT JOIN filiais f ON a.filial_id=f.id LEFT JOIN users u ON a.registrado_por=u.id $where ORDER BY a.created_at DESC", $params);
$edit   = $id ? DB::one("SELECT a.*,f.nome as filial_nome FROM achados_perdidos a LEFT JOIN filiais f ON a.filial_id=f.id WHERE a.id=?",[$id]) : null;

page_start('Achados e Perdidos','achados');
pageHeader('🔍 Achados e Perdidos','Registro e controle de itens encontrados',[
    ['label'=>'+ Registrar Item','href'=>'#','onclick'=>"openModal('modalAchado')",'cls'=>'btn-primary'],
]);
flashMessage();
?>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
<?php
statCard('Guardados',DB::count('achados_perdidos',"status='guardado'"),'📦','blue');
statCard('Entregues',DB::count('achados_perdidos',"status='entregue'"),'✅','green');
statCard('Doações',  DB::count('achados_perdidos',"status='doado'"),   '💝','purple');
statCard('Caju-RJ',  DB::count('achados_perdidos',"status='enviado_caju'"),'📮','brand');
?>
</div>

<!-- Filtros -->
<div class="filters-bar" style="margin-bottom:12px">
  <?php foreach ([''=>'Todos','guardado'=>'Guardados','entregue'=>'Entregues','doado'=>'Doados','enviado_caju'=>'Caju-RJ','descartado'=>'Descartados'] as $v=>$l): ?>
  <a href="<?= url('/pages/achados.php?status='.$v) ?>" class="btn btn-sm <?= $filter===$v?'btn-primary':'btn-outline' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="table-wrapper"><table class="data-table">
    <thead><tr><th>Título</th><th>Categoria</th><th>Cor/Marca</th><th>Filial</th><th>Local</th><th>Encontrado em</th><th>Proprietário</th><th>Status</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($lista as $i): ?>
    <tr>
      <td><strong><?= htmlspecialchars($i['titulo']) ?></strong></td>
      <td><?= ucfirst($i['categoria']) ?></td>
      <td><?= htmlspecialchars(trim(($i['cor']??'').($i['marca']?' / '.$i['marca']:''),', ')) ?></td>
      <td><?= htmlspecialchars($i['filial_nome']??'—') ?></td>
      <td><?= htmlspecialchars($i['local_encontrado']??'—') ?></td>
      <td class="td-mono"><?= formatDate($i['data_encontrado']) ?></td>
      <td><?= htmlspecialchars($i['proprietario']??'—') ?><?= $i['cpf_proprietario']?"<br><span class='text-xs text-muted'>{$i['cpf_proprietario']}</span>":'' ?></td>
      <td><?= statusBadge($i['status']) ?></td>
      <td><a href="<?= url('/pages/achados.php?id='.$i['id']) ?>" class="btn btn-xs btn-outline">Ver/Editar</a></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<?php if ($edit): ?>
<div class="dashboard-grid">
<div class="card">
  <div class="card-header">
    <span class="card-title">🔍 <?= htmlspecialchars($edit['titulo']) ?></span>
    <?= statusBadge($edit['status']) ?>
    <a href="<?= url('/pages/achados.php') ?>" class="btn btn-ghost btn-sm" style="margin-left:auto">← Voltar</a>
  </div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="salvar"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
      <?php renderFormAchado($edit); ?>
      <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar</button></div>
    </form>
  </div>
</div>

<!-- Destinação -->
<?php if ($edit['status'] === 'guardado'): ?>
<div class="card" style="height:fit-content">
  <div class="card-header"><span class="card-title">📦 Registrar Destinação</span></div>
  <div class="card-body">
    <form method="POST"><input type="hidden" name="_action" value="destinacao"><input type="hidden" name="id" value="<?= $edit['id'] ?>">
      <div class="form-group mb-2"><label class="form-label">Destinação</label>
        <select name="destinacao" class="form-select" onchange="toggleDestinatario(this.value)">
          <option value="devolucao">Devolução ao proprietário</option>
          <option value="doacao">Doação</option>
          <option value="caju_rj">Envio Caju-RJ</option>
          <option value="descarte">Descarte</option>
        </select></div>
      <div class="form-group mb-2"><label class="form-label">Status resultante</label>
        <select name="status" class="form-select">
          <option value="entregue">Entregue</option>
          <option value="doado">Doado</option>
          <option value="enviado_caju">Enviado Caju-RJ</option>
          <option value="descartado">Descartado</option>
        </select></div>
      <div class="form-group mb-2"><label class="form-label">Data</label><input type="date" name="data" class="form-input" value="<?= date('Y-m-d') ?>"></div>
      <div class="form-group mb-2"><label class="form-label">Observação</label><textarea name="obs" class="form-textarea" rows="3" placeholder="Nome do destinatário, documento, etc..."></textarea></div>
      <button type="submit" class="btn btn-success" style="width:100%;justify-content:center">✓ Confirmar Destinação</button>
    </form>
  </div>
</div>
<?php else: ?>
<div class="card" style="height:fit-content">
  <div class="card-header"><span class="card-title">📋 Destinação Registrada</span></div>
  <div class="card-body">
    <p class="text-sm" style="margin-bottom:8px"><strong>Tipo:</strong> <?= ucfirst(str_replace('_',' ',$edit['destinacao'])) ?></p>
    <?php if ($edit['data_devolucao']): ?><p class="text-sm" style="margin-bottom:8px"><strong>Data:</strong> <?= formatDate($edit['data_devolucao']) ?></p><?php endif; ?>
    <?php if ($edit['proprietario']): ?><p class="text-sm" style="margin-bottom:8px"><strong>Proprietário:</strong> <?= htmlspecialchars($edit['proprietario']) ?></p><?php endif; ?>
    <?php if ($edit['obs_destinacao']): ?><p class="text-sm"><strong>Obs:</strong> <?= nl2br(htmlspecialchars($edit['obs_destinacao'])) ?></p><?php endif; ?>
  </div>
</div>
<?php endif; ?>
</div><!-- /grid -->
<?php renderComentarios('achado', $edit['id']); ?>
<?php endif; ?>

<div class="modal-overlay" id="modalAchado">
  <div class="modal modal-lg"><div class="modal-header"><span class="modal-title">🔍 Registrar Item Encontrado</span><button class="modal-close" onclick="closeModal('modalAchado')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="salvar">
  <div class="modal-body"><?php renderFormAchado(); ?></div>
  <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalAchado')">Cancelar</button><button type="submit" class="btn btn-primary">Registrar</button></div>
  </form></div>
</div>

<?php
function renderFormAchado(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
  <div class="form-group" style="grid-column:span 2"><label class="form-label">Descrição do Item *</label><input type="text" name="titulo" class="form-input" required value="<?= htmlspecialchars($d['titulo']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Categoria</label>
    <select name="categoria" class="form-select"><?= selectOptions([['v'=>'documento','l'=>'Documento'],['v'=>'eletronico','l'=>'Eletrônico'],['v'=>'vestuario','l'=>'Vestuário'],['v'=>'acessorio','l'=>'Acessório'],['v'=>'outros','l'=>'Outros']],'v','l',$d['categoria']??'outros') ?></select></div>
  <div class="form-group"><label class="form-label">Cor</label><input type="text" name="cor" class="form-input" placeholder="Preto, azul..." value="<?= htmlspecialchars($d['cor']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Marca</label><input type="text" name="marca" class="form-input" value="<?= htmlspecialchars($d['marca']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Filial</label><select name="filial_id" class="form-select"><?= selectOptions(filiais(),'id','nome',$d['filial_id']??null) ?></select></div>
  <div class="form-group"><label class="form-label">Local Encontrado</label><input type="text" name="local_encontrado" class="form-input" value="<?= htmlspecialchars($d['local_encontrado']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Data Encontrado *</label><input type="date" name="data_encontrado" class="form-input" required value="<?= $d['data_encontrado']??date('Y-m-d') ?>"></div>
  <div class="form-group"><label class="form-label">Encontrado por</label><input type="text" name="encontrado_por" class="form-input" value="<?= htmlspecialchars($d['encontrado_por']??'') ?>"></div>
  <div class="form-group"><label class="form-label">Status</label>
    <select name="status" class="form-select"><?= selectOptions([['v'=>'guardado','l'=>'Guardado'],['v'=>'entregue','l'=>'Entregue'],['v'=>'doado','l'=>'Doado'],['v'=>'enviado_caju','l'=>'Enviado Caju-RJ'],['v'=>'descartado','l'=>'Descartado']],'v','l',$d['status']??'guardado') ?></select></div>
  <div class="form-group"><label class="form-label">Proprietário</label><input type="text" name="proprietario" class="form-input" value="<?= htmlspecialchars($d['proprietario']??'') ?>"></div>
  <div class="form-group"><label class="form-label">CPF Proprietário</label><input type="text" name="cpf_proprietario" class="form-input" placeholder="000.000.000-00" value="<?= htmlspecialchars($d['cpf_proprietario']??'') ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Descrição detalhada</label><textarea name="descricao" class="form-textarea" rows="3"><?= htmlspecialchars($d['descricao']??'') ?></textarea></div>
<?php }
page_end(); ?>
