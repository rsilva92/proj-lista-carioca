<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
require_once __DIR__ . '/../../includes/comentarios.php';
Auth::start(); Auth::require();
$tab = $_GET['tab'] ?? 'equipamentos';
$id  = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST; $a = $p['_action'] ?? '';
    if ($a === 'equip_salvar') {
        $campos = ['nome','tipo','marca','modelo','numero_serie','ip_address','hostname',
                   'patrimonio','codigo','filial_id','localizacao','status','responsavel_id',
                   'fornecedor_id','data_aquisicao','valor','garantia_ate','vida_util','obs'];
        if ($p['id']??0) {
            $sets = implode(',',array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos); $vals[] = $p['id'];
            DB::run("UPDATE equipamentos SET $sets WHERE id=?", $vals);
            setFlash('Equipamento atualizado!','success');
        } else {
            if (!($p['codigo']??'')) $p['codigo'] = gerarNumero('EQ','equipamentos','codigo');
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            DB::insert("INSERT INTO equipamentos (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            setFlash('Equipamento cadastrado!','success');
        }
        header('Location: '.url('/pages/ativos.php?tab=equipamentos')); exit;
    }
    if ($a === 'predial_salvar') {
        $campos = ['filial_id','area','tipo','metragem','descricao','status','responsavel_id',
                   'ultima_vistoria','proxima_vistoria','obs'];
        if ($p['id']??0) {
            $sets = implode(',',array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos); $vals[] = $p['id'];
            DB::run("UPDATE predial SET $sets WHERE id=?", $vals);
            setFlash('Área atualizada!','success');
        } else {
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            DB::insert("INSERT INTO predial (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            setFlash('Área cadastrada!','success');
        }
        header('Location: '.url('/pages/ativos.php?tab=predial')); exit;
    }
    if ($a === 'manut_salvar') {
        $campos = ['tipo_ref','ref_id','tipo','titulo','descricao','status','fornecedor_id',
                   'responsavel_id','data_agendada','data_realizada','custo','chamado_id','obs'];
        if ($p['id']??0) {
            $sets = implode(',',array_map(fn($c)=>"$c=?", $campos));
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos); $vals[] = $p['id'];
            DB::run("UPDATE manutencoes SET $sets WHERE id=?", $vals);
            setFlash('Manutenção atualizada!','success');
        } else {
            $p['numero'] = gerarNumero('MAN','manutencoes','numero');
            array_unshift($campos,'numero');
            $vals = array_map(fn($c)=>($p[$c]??'')?:null, $campos);
            DB::insert("INSERT INTO manutencoes (".implode(',',$campos).") VALUES (".implode(',',array_fill(0,count($campos),'?')).")", $vals);
            setFlash('Manutenção registrada!','success');
        }
        header('Location: '.url('/pages/ativos.php?tab=manutencoes')); exit;
    }
    if ($a === 'equip_excluir') {
        DB::run('DELETE FROM equipamentos WHERE id=?',[$p['id']]);
        setFlash('Excluído!','success');
        header('Location: '.url('/pages/ativos.php?tab=equipamentos')); exit;
    }
}

$editEquip   = $id&&$tab==='equipamentos' ? DB::one('SELECT * FROM equipamentos WHERE id=?',[$id]) : null;
$editPredial = $id&&$tab==='predial'      ? DB::one('SELECT * FROM predial WHERE id=?',[$id])       : null;
$editManut   = $id&&$tab==='manutencoes'  ? DB::one('SELECT * FROM manutencoes WHERE id=?',[$id])   : null;

$equipamentos = DB::all("SELECT e.*,f.nome as filial_nome,u.nome as resp_nome FROM equipamentos e LEFT JOIN filiais f ON e.filial_id=f.id LEFT JOIN users u ON e.responsavel_id=u.id ORDER BY e.nome");
$prediais     = DB::all("SELECT p.*,f.nome as filial_nome,u.nome as resp_nome FROM predial p LEFT JOIN filiais f ON p.filial_id=f.id LEFT JOIN users u ON p.responsavel_id=u.id ORDER BY f.nome,p.area");
$manutencoes  = DB::all("SELECT m.*,u.nome as resp_nome FROM manutencoes m LEFT JOIN users u ON m.responsavel_id=u.id ORDER BY m.created_at DESC");

page_start('Ativos','ativos');
pageHeader('🖥 Ativos & Equipamentos','Equipamentos, infraestrutura predial e manutenções');
flashMessage();
?>
<div class="tabs">
  <button class="tab-btn <?= $tab==='equipamentos'?'active':'' ?>" onclick="window.location='<?= url('/pages/ativos.php?tab=equipamentos') ?>'">🖥 Equipamentos</button>
  <button class="tab-btn <?= $tab==='predial'?'active':'' ?>"      onclick="window.location='<?= url('/pages/ativos.php?tab=predial') ?>'">🏢 Predial</button>
  <button class="tab-btn <?= $tab==='manutencoes'?'active':'' ?>"  onclick="window.location='<?= url('/pages/ativos.php?tab=manutencoes') ?>'">🔧 Manutenções</button>
</div>

<?php if ($tab==='equipamentos'): ?>
<div style="margin-bottom:12px"><button class="btn btn-primary" onclick="openModal('modalEquip')">+ Novo Equipamento</button></div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
<?php statCard('Ativos',DB::count('equipamentos',"status='ativo'"),'✅','green');
statCard('Manutenção',DB::count('equipamentos',"status='manutencao'"),'🔧','yellow');
statCard('Inativos',DB::count('equipamentos',"status='inativo'"),'⛔','gray');
statCard('Garantia vencida',DB::count('equipamentos',"status='ativo' AND garantia_ate < CURDATE()"),'⚠️','red'); ?>
</div>
<div class="card"><div class="table-wrapper"><table class="data-table">
<thead><tr><th>Código</th><th>Nome</th><th>Tipo</th><th>Marca/Modelo</th><th>Filial</th><th>Localização</th><th>Status</th><th>Garantia</th><th>Responsável</th><th>Ações</th></tr></thead>
<tbody>
<?php foreach ($equipamentos as $e):
  $gV = $e['garantia_ate'] && $e['garantia_ate'] < date('Y-m-d'); ?>
<tr>
<td class="td-mono"><?= htmlspecialchars($e['codigo']) ?></td>
<td><strong><?= htmlspecialchars($e['nome']) ?></strong><?= $e['patrimonio']?"<br><span class='text-xs text-muted'>Pat: {$e['patrimonio']}</span>":'' ?></td>
<td><?= ucfirst(str_replace('_',' ',$e['tipo'])) ?></td>
<td><?= htmlspecialchars(trim(($e['marca']??'').' '.($e['modelo']??''))) ?></td>
<td><?= htmlspecialchars($e['filial_nome']??'—') ?></td>
<td><?= htmlspecialchars($e['localizacao']??'—') ?></td>
<td><?= statusBadge($e['status']) ?></td>
<td class="td-mono <?= $gV?'text-red':'' ?>"><?= $e['garantia_ate']?formatDate($e['garantia_ate']):'—' ?><?= $gV?" <span class='badge badge-red'>Vencida</span>":'' ?></td>
<td><?= htmlspecialchars($e['resp_nome']??'—') ?></td>
<td class="td-actions">
  <a href="<?= url('/pages/ativos.php?tab=equipamentos&id='.$e['id']) ?>" class="btn btn-xs btn-outline">✏ Editar</a>
  <form method="POST" style="display:inline" onsubmit="return confirm('Excluir?')">
    <input type="hidden" name="_action" value="equip_excluir"><input type="hidden" name="id" value="<?= $e['id'] ?>">
    <button class="btn btn-xs btn-danger">✕</button>
  </form>
</td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php if ($editEquip): ?>
<div class="card mt-2">
  <div class="card-header"><span class="card-title">✏ Editando: <?= htmlspecialchars($editEquip['nome']) ?></span><a href="<?= url('/pages/ativos.php?tab=equipamentos') ?>" class="btn btn-ghost btn-sm">✕</a></div>
  <div class="card-body"><form method="POST"><input type="hidden" name="_action" value="equip_salvar"><input type="hidden" name="id" value="<?= $editEquip['id'] ?>">
    <?php renderFormEquip($editEquip); ?>
    <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar</button></div>
  </form></div>
</div>
<?php renderComentarios('equipamento',$editEquip['id']); ?>
<?php endif; ?>
<div class="modal-overlay" id="modalEquip"><div class="modal modal-lg">
  <div class="modal-header"><span class="modal-title">🖥 Novo Equipamento</span><button class="modal-close" onclick="closeModal('modalEquip')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="equip_salvar">
    <div class="modal-body"><?php renderFormEquip(); ?></div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalEquip')">Cancelar</button><button type="submit" class="btn btn-primary">Cadastrar</button></div>
  </form></div></div>

<?php elseif ($tab==='predial'): ?>
<div style="margin-bottom:12px"><button class="btn btn-primary" onclick="openModal('modalPredial')">+ Nova Área</button></div>
<div class="card"><div class="table-wrapper"><table class="data-table">
<thead><tr><th>Filial</th><th>Área</th><th>Tipo</th><th>m²</th><th>Status</th><th>Última Vistoria</th><th>Próxima Vistoria</th><th>Responsável</th><th>Ações</th></tr></thead>
<tbody>
<?php foreach ($prediais as $p):
  $venc = $p['proxima_vistoria'] && $p['proxima_vistoria'] < date('Y-m-d'); ?>
<tr>
<td><?= htmlspecialchars($p['filial_nome']) ?></td>
<td><strong><?= htmlspecialchars($p['area']) ?></strong></td>
<td><?= ucfirst(str_replace('_',' ',$p['tipo'])) ?></td>
<td><?= $p['metragem']?number_format($p['metragem'],1).' m²':'—' ?></td>
<td><?= statusBadge($p['status']) ?></td>
<td class="td-mono"><?= $p['ultima_vistoria']?formatDate($p['ultima_vistoria']):'—' ?></td>
<td class="td-mono <?= $venc?'text-red':'' ?>"><?= $p['proxima_vistoria']?formatDate($p['proxima_vistoria']):'—' ?><?= $venc?" <span class='badge badge-red'>Vencida</span>":'' ?></td>
<td><?= htmlspecialchars($p['resp_nome']??'—') ?></td>
<td><a href="<?= url('/pages/ativos.php?tab=predial&id='.$p['id']) ?>" class="btn btn-xs btn-outline">✏</a></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php if ($editPredial): ?>
<div class="card mt-2">
  <div class="card-header"><span class="card-title">✏ <?= htmlspecialchars($editPredial['area']) ?></span><a href="<?= url('/pages/ativos.php?tab=predial') ?>" class="btn btn-ghost btn-sm">✕</a></div>
  <div class="card-body"><form method="POST"><input type="hidden" name="_action" value="predial_salvar"><input type="hidden" name="id" value="<?= $editPredial['id'] ?>">
    <?php renderFormPredial($editPredial); ?>
    <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar</button></div>
  </form></div>
</div>
<?php renderComentarios('predial',$editPredial['id']); ?>
<?php endif; ?>
<div class="modal-overlay" id="modalPredial"><div class="modal">
  <div class="modal-header"><span class="modal-title">🏢 Nova Área</span><button class="modal-close" onclick="closeModal('modalPredial')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="predial_salvar">
    <div class="modal-body"><?php renderFormPredial(); ?></div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalPredial')">Cancelar</button><button type="submit" class="btn btn-primary">Cadastrar</button></div>
  </form></div></div>

<?php elseif ($tab==='manutencoes'): ?>
<div style="margin-bottom:12px"><button class="btn btn-primary" onclick="openModal('modalManut')">+ Nova Manutenção</button></div>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
<?php statCard('Agendadas',DB::count('manutencoes',"status='agendada'"),'📅','blue');
statCard('Em Andamento',DB::count('manutencoes',"status='em_andamento'"),'⚙','yellow');
statCard('Concluídas mês',DB::count('manutencoes',"status='concluida' AND MONTH(data_realizada)=MONTH(NOW())"),'✅','green');
$cm = DB::one("SELECT SUM(custo) as t FROM manutencoes WHERE status='concluida' AND MONTH(data_realizada)=MONTH(NOW())")['t']??0;
statCard('Custo Mês',formatMoney((float)$cm),'💰','orange'); ?>
</div>
<div class="card"><div class="table-wrapper"><table class="data-table">
<thead><tr><th>Número</th><th>Título</th><th>Tipo</th><th>Referência</th><th>Status</th><th>Agendada</th><th>Realizada</th><th>Custo</th><th>Responsável</th><th>Ações</th></tr></thead>
<tbody>
<?php foreach ($manutencoes as $m): ?>
<tr>
<td class="td-mono"><?= htmlspecialchars($m['numero']??'—') ?></td>
<td><strong><?= htmlspecialchars($m['titulo']) ?></strong></td>
<td><?= ucfirst($m['tipo']) ?></td>
<td class="text-xs"><?= ucfirst($m['tipo_ref']).' #'.$m['ref_id'] ?></td>
<td><?= statusBadge($m['status']) ?></td>
<td class="td-mono"><?= $m['data_agendada']?formatDate($m['data_agendada']):'—' ?></td>
<td class="td-mono"><?= $m['data_realizada']?formatDate($m['data_realizada']):'—' ?></td>
<td><?= $m['custo']?formatMoney($m['custo']):'—' ?></td>
<td><?= htmlspecialchars($m['resp_nome']??'—') ?></td>
<td><a href="<?= url('/pages/ativos.php?tab=manutencoes&id='.$m['id']) ?>" class="btn btn-xs btn-outline">✏</a></td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div>
<?php if ($editManut): ?>
<div class="card mt-2">
  <div class="card-header"><span class="card-title">✏ <?= htmlspecialchars($editManut['titulo']) ?></span><a href="<?= url('/pages/ativos.php?tab=manutencoes') ?>" class="btn btn-ghost btn-sm">✕</a></div>
  <div class="card-body"><form method="POST"><input type="hidden" name="_action" value="manut_salvar"><input type="hidden" name="id" value="<?= $editManut['id'] ?>">
    <?php renderFormManut($editManut); ?>
    <div class="btn-row mt-2"><button class="btn btn-primary">💾 Salvar</button></div>
  </form></div>
</div>
<?php renderComentarios('manutencao',$editManut['id']); ?>
<?php endif; ?>
<div class="modal-overlay" id="modalManut"><div class="modal modal-lg">
  <div class="modal-header"><span class="modal-title">🔧 Nova Manutenção</span><button class="modal-close" onclick="closeModal('modalManut')">✕</button></div>
  <form method="POST"><input type="hidden" name="_action" value="manut_salvar">
    <div class="modal-body"><?php renderFormManut(); ?></div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalManut')">Cancelar</button><button type="submit" class="btn btn-primary">Registrar</button></div>
  </form></div></div>
<?php endif; ?>

<?php
function renderFormEquip(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
<div class="form-group"><label class="form-label">Nome *</label><input type="text" name="nome" class="form-input" required value="<?= htmlspecialchars($d['nome']??'') ?>"></div>
<div class="form-group"><label class="form-label">Código</label><input type="text" name="codigo" class="form-input" placeholder="Auto" value="<?= htmlspecialchars($d['codigo']??'') ?>"></div>
<div class="form-group"><label class="form-label">Patrimônio</label><input type="text" name="patrimonio" class="form-input" value="<?= htmlspecialchars($d['patrimonio']??'') ?>"></div>
<div class="form-group"><label class="form-label">Tipo</label><select name="tipo" class="form-select"><?= selectOptions([['v'=>'computador','l'=>'Computador'],['v'=>'impressora','l'=>'Impressora'],['v'=>'servidor','l'=>'Servidor'],['v'=>'telefone','l'=>'Telefone'],['v'=>'ar_condicionado','l'=>'Ar-condicionado'],['v'=>'camera','l'=>'Câmera'],['v'=>'outros','l'=>'Outros']],'v','l',$d['tipo']??'outros') ?></select></div>
<div class="form-group"><label class="form-label">Marca</label><input type="text" name="marca" class="form-input" value="<?= htmlspecialchars($d['marca']??'') ?>"></div>
<div class="form-group"><label class="form-label">Modelo</label><input type="text" name="modelo" class="form-input" value="<?= htmlspecialchars($d['modelo']??'') ?>"></div>
<div class="form-group"><label class="form-label">Nº Série</label><input type="text" name="numero_serie" class="form-input" value="<?= htmlspecialchars($d['numero_serie']??'') ?>"></div>
<div class="form-group"><label class="form-label">IP</label><input type="text" name="ip_address" class="form-input" value="<?= htmlspecialchars($d['ip_address']??'') ?>"></div>
<div class="form-group"><label class="form-label">Hostname</label><input type="text" name="hostname" class="form-input" value="<?= htmlspecialchars($d['hostname']??'') ?>"></div>
<div class="form-group"><label class="form-label">Filial</label><select name="filial_id" class="form-select"><?= selectOptions(filiais(),'id','nome',$d['filial_id']??null) ?></select></div>
<div class="form-group"><label class="form-label">Localização</label><input type="text" name="localizacao" class="form-input" value="<?= htmlspecialchars($d['localizacao']??'') ?>"></div>
<div class="form-group"><label class="form-label">Status</label><select name="status" class="form-select"><?= selectOptions([['v'=>'ativo','l'=>'Ativo'],['v'=>'manutencao','l'=>'Em Manutenção'],['v'=>'inativo','l'=>'Inativo'],['v'=>'descartado','l'=>'Descartado']],'v','l',$d['status']??'ativo') ?></select></div>
<div class="form-group"><label class="form-label">Aquisição</label><input type="date" name="data_aquisicao" class="form-input" value="<?= $d['data_aquisicao']??'' ?>"></div>
<div class="form-group"><label class="form-label">Valor (R$)</label><input type="number" name="valor" class="form-input" step="0.01" value="<?= $d['valor']??'' ?>"></div>
<div class="form-group"><label class="form-label">Garantia até</label><input type="date" name="garantia_ate" class="form-input" value="<?= $d['garantia_ate']??'' ?>"></div>
<div class="form-group"><label class="form-label">Vida útil (anos)</label><input type="number" name="vida_util" class="form-input" value="<?= $d['vida_util']??'' ?>"></div>
<div class="form-group"><label class="form-label">Responsável</label><select name="responsavel_id" class="form-select"><?= selectOptions(users(),'id','nome',$d['responsavel_id']??null) ?></select></div>
<div class="form-group"><label class="form-label">Fornecedor</label><select name="fornecedor_id" class="form-select"><?= selectOptions(fornecedores(),'id','razao_social',$d['fornecedor_id']??null) ?></select></div>
</div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="3"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }
function renderFormPredial(array $d = []): void { ?>
<div class="form-grid form-grid-2" style="gap:12px">
<div class="form-group"><label class="form-label">Filial *</label><select name="filial_id" class="form-select" required><?= selectOptions(filiais(),'id','nome',$d['filial_id']??null) ?></select></div>
<div class="form-group"><label class="form-label">Área / Setor *</label><input type="text" name="area" class="form-input" required value="<?= htmlspecialchars($d['area']??'') ?>"></div>
<div class="form-group"><label class="form-label">Tipo</label><select name="tipo" class="form-select"><?= selectOptions([['v'=>'eletrica','l'=>'Elétrica'],['v'=>'hidraulica','l'=>'Hidráulica'],['v'=>'civil','l'=>'Civil'],['v'=>'ar_condicionado','l'=>'Ar-condicionado'],['v'=>'seguranca','l'=>'Segurança'],['v'=>'outros','l'=>'Outros']],'v','l',$d['tipo']??'outros') ?></select></div>
<div class="form-group"><label class="form-label">Metragem (m²)</label><input type="number" name="metragem" class="form-input" step="0.01" value="<?= $d['metragem']??'' ?>"></div>
<div class="form-group"><label class="form-label">Status</label><select name="status" class="form-select"><?= selectOptions([['v'=>'ok','l'=>'✅ OK'],['v'=>'atencao','l'=>'⚠ Atenção'],['v'=>'critico','l'=>'🔴 Crítico']],'v','l',$d['status']??'ok') ?></select></div>
<div class="form-group"><label class="form-label">Responsável</label><select name="responsavel_id" class="form-select"><?= selectOptions(users(),'id','nome',$d['responsavel_id']??null) ?></select></div>
<div class="form-group"><label class="form-label">Última Vistoria</label><input type="date" name="ultima_vistoria" class="form-input" value="<?= $d['ultima_vistoria']??'' ?>"></div>
<div class="form-group"><label class="form-label">Próxima Vistoria</label><input type="date" name="proxima_vistoria" class="form-input" value="<?= $d['proxima_vistoria']??'' ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Descrição</label><textarea name="descricao" class="form-textarea"><?= htmlspecialchars($d['descricao']??'') ?></textarea></div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="2"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }
function renderFormManut(array $d = []): void { ?>
<div class="form-grid form-grid-3" style="gap:12px">
<div class="form-group" style="grid-column:span 2"><label class="form-label">Título *</label><input type="text" name="titulo" class="form-input" required value="<?= htmlspecialchars($d['titulo']??'') ?>"></div>
<div class="form-group"><label class="form-label">Tipo Ref.</label><select name="tipo_ref" class="form-select"><option value="equipamento" <?= ($d['tipo_ref']??'')==='equipamento'?'selected':'' ?>>Equipamento</option><option value="predial" <?= ($d['tipo_ref']??'')==='predial'?'selected':'' ?>>Predial</option></select></div>
<div class="form-group"><label class="form-label">ID da Referência</label><input type="number" name="ref_id" class="form-input" value="<?= $d['ref_id']??'' ?>"></div>
<div class="form-group"><label class="form-label">Tipo</label><select name="tipo" class="form-select"><?= selectOptions([['v'=>'preventiva','l'=>'Preventiva'],['v'=>'corretiva','l'=>'Corretiva'],['v'=>'preditiva','l'=>'Preditiva']],'v','l',$d['tipo']??'corretiva') ?></select></div>
<div class="form-group"><label class="form-label">Status</label><select name="status" class="form-select"><?= selectOptions([['v'=>'agendada','l'=>'Agendada'],['v'=>'em_andamento','l'=>'Em Andamento'],['v'=>'concluida','l'=>'Concluída'],['v'=>'cancelada','l'=>'Cancelada']],'v','l',$d['status']??'agendada') ?></select></div>
<div class="form-group"><label class="form-label">Fornecedor</label><select name="fornecedor_id" class="form-select"><?= selectOptions(fornecedores(),'id','razao_social',$d['fornecedor_id']??null) ?></select></div>
<div class="form-group"><label class="form-label">Responsável</label><select name="responsavel_id" class="form-select"><?= selectOptions(users(),'id','nome',$d['responsavel_id']??null) ?></select></div>
<div class="form-group"><label class="form-label">Data Agendada</label><input type="date" name="data_agendada" class="form-input" value="<?= $d['data_agendada']??'' ?>"></div>
<div class="form-group"><label class="form-label">Data Realizada</label><input type="date" name="data_realizada" class="form-input" value="<?= $d['data_realizada']??'' ?>"></div>
<div class="form-group"><label class="form-label">Custo (R$)</label><input type="number" name="custo" class="form-input" step="0.01" value="<?= $d['custo']??'' ?>"></div>
<div class="form-group"><label class="form-label">Chamado vinculado</label><input type="number" name="chamado_id" class="form-input" placeholder="ID" value="<?= $d['chamado_id']??'' ?>"></div>
</div>
<div class="form-group mt-1"><label class="form-label">Descrição</label><textarea name="descricao" class="form-textarea"><?= htmlspecialchars($d['descricao']??'') ?></textarea></div>
<div class="form-group mt-1"><label class="form-label">Observações</label><textarea name="obs" class="form-textarea" rows="2"><?= htmlspecialchars($d['obs']??'') ?></textarea></div>
<?php }
page_end(); ?>
