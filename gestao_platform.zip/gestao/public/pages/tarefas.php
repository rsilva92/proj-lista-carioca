<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';

Auth::start(); Auth::require();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST;
    if ($p['_action'] === 'criar') {
        DB::insert("INSERT INTO tarefas (titulo,descricao,prioridade,responsavel_id,filial_id,data_inicio,data_fim,criado_por) VALUES (?,?,?,?,?,?,?,?)",
            [$p['titulo'],$p['descricao'],$p['prioridade'],$p['responsavel_id']?:null,$p['filial_id']?:null,$p['data_inicio']?:null,$p['data_fim']?:null,Auth::id()]);
        setFlash('Tarefa criada!','success');
    } elseif ($p['_action'] === 'status' && isset($p['id'])) {
        $done = $p['status'] === 'concluida' ? 'NOW()' : 'NULL';
        DB::run("UPDATE tarefas SET status=?,data_conclusao=IF(status='concluida',NOW(),NULL) WHERE id=?",[$p['status'],$p['id']]);
        setFlash('Status atualizado!','success');
    }
    header('Location: ' . url('/pages/tarefas.php')); exit;
}

$tarefas = DB::all("SELECT t.*,u.nome as resp_nome,f.nome as filial_nome FROM tarefas t LEFT JOIN users u ON t.responsavel_id=u.id LEFT JOIN filiais f ON t.filial_id=f.id ORDER BY FIELD(t.prioridade,'urgente','alta','media','baixa'), t.data_fim ASC");

page_start('Tarefas','tarefas');
pageHeader('✓ Tarefas & Agenda','Gerenciamento de tarefas e lembretes',[
    ['label'=>'+ Nova Tarefa','href'=>'#','onclick'=>"openModal('modalTarefa')",'cls'=>'btn-primary'],
]);
flashMessage();
?>
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
<?php
statCard('Pendentes',DB::count('tarefas',"status='pendente'"),'📋','yellow');
statCard('Em Andamento',DB::count('tarefas',"status='em_andamento'"),'⚡','blue');
statCard('Concluídas hoje',DB::count('tarefas',"status='concluida' AND DATE(data_conclusao)=CURDATE()"),'✅','green');
statCard('Atrasadas',DB::count('tarefas',"status NOT IN ('concluida','cancelada') AND data_fim < CURDATE()"),'❗','red');
?>
</div>
<div class="card">
<div class="table-wrapper"><table class="data-table">
<thead><tr><th>Título</th><th>Prioridade</th><th>Responsável</th><th>Filial</th><th>Prazo</th><th>Status</th><th>Ações</th></tr></thead>
<tbody>
<?php foreach ($tarefas as $t):
$dias = $t['data_fim'] ? diasRestantes($t['data_fim']) : null;
$atraso = $dias !== null && $dias < 0 && !in_array($t['status'],['concluida','cancelada']);
?>
<tr>
<td><strong><?= htmlspecialchars($t['titulo']) ?></strong><?php if ($t['descricao']): ?><br><span class="text-xs text-muted"><?= htmlspecialchars(substr($t['descricao'],0,60)) ?>...</span><?php endif; ?></td>
<td><?= prioridadeIcon($t['prioridade']) ?> <?= statusBadge($t['prioridade']) ?></td>
<td><?= htmlspecialchars($t['resp_nome']??'—') ?></td>
<td><?= htmlspecialchars($t['filial_nome']??'—') ?></td>
<td class="td-mono <?= $atraso?'text-red':'' ?>"><?= $t['data_fim']?formatDate($t['data_fim']):'—' ?><?= $atraso?" <span class='badge badge-red'>Atrasada</span>":'' ?></td>
<td><?= statusBadge($t['status']) ?></td>
<td class="td-actions">
<form method="POST" style="display:inline">
<input type="hidden" name="_action" value="status">
<input type="hidden" name="id" value="<?= $t['id'] ?>">
<?php if ($t['status'] !== 'concluida'): ?>
<button name="status" value="concluida" class="btn btn-xs btn-success">✓</button>
<?php endif; ?>
<?php if ($t['status'] === 'pendente'): ?>
<button name="status" value="em_andamento" class="btn btn-xs btn-outline">▶</button>
<?php endif; ?>
</form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table></div>
</div>

<div class="modal-overlay" id="modalTarefa">
<div class="modal"><div class="modal-header"><span class="modal-title">✓ Nova Tarefa</span><button class="modal-close" onclick="closeModal('modalTarefa')">✕</button></div>
<form method="POST"><input type="hidden" name="_action" value="criar">
<div class="modal-body"><div class="form-grid" style="gap:12px">
<div class="form-group"><label class="form-label">Título *</label><input type="text" name="titulo" class="form-input" required></div>
<div class="form-grid form-grid-2">
<div class="form-group"><label class="form-label">Prioridade</label><select name="prioridade" class="form-select"><option value="baixa">🟢 Baixa</option><option value="media" selected>🟡 Média</option><option value="alta">🟠 Alta</option><option value="urgente">🔴 Urgente</option></select></div>
<div class="form-group"><label class="form-label">Responsável</label><select name="responsavel_id" class="form-select"><?= selectOptions(users(),'id','nome',Auth::id()) ?></select></div>
<div class="form-group"><label class="form-label">Filial</label><select name="filial_id" class="form-select"><?= selectOptions(filiais(),'id','nome') ?></select></div>
<div class="form-group"><label class="form-label">Data Início</label><input type="date" name="data_inicio" class="form-input" value="<?= date('Y-m-d') ?>"></div>
<div class="form-group"><label class="form-label">Prazo</label><input type="date" name="data_fim" class="form-input"></div>
</div>
<div class="form-group"><label class="form-label">Descrição</label><textarea name="descricao" class="form-textarea"></textarea></div>
</div></div>
<div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal('modalTarefa')">Cancelar</button><button type="submit" class="btn btn-primary">Criar Tarefa</button></div>
</form></div></div>

<?php page_end(); ?>
