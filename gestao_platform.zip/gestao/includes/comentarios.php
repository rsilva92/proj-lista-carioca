<?php
// includes/comentarios.php — Componente reutilizável de comentários

function renderComentarios(string $modulo, int $refId): void {
    $comentarios = DB::all(
        "SELECT c.*, u.nome as user_nome
         FROM comentarios c
         LEFT JOIN users u ON c.user_id = u.id
         WHERE c.modulo = ? AND c.ref_id = ?
         ORDER BY c.created_at ASC",
        [$modulo, $refId]
    );
    ?>
    <div class="card mt-2" id="comentarios-section">
      <div class="card-header">
        <span class="card-title">💬 Comentários <span class="badge badge-gray"><?= count($comentarios) ?></span></span>
      </div>
      <div class="card-body" style="padding-bottom:8px">

        <!-- Lista de comentários -->
        <div id="comentarios-lista">
        <?php if (empty($comentarios)): ?>
          <p class="text-muted text-sm" style="padding:8px 0">Nenhum comentário ainda.</p>
        <?php else: foreach ($comentarios as $c): ?>
          <div class="comentario-item" id="cmt-<?= $c['id'] ?>">
            <div class="comentario-header">
              <div class="comentario-avatar"><?= strtoupper(substr($c['user_nome'] ?? 'S', 0, 2)) ?></div>
              <div>
                <strong class="comentario-autor"><?= htmlspecialchars($c['user_nome'] ?? 'Sistema') ?></strong>
                <span class="comentario-data text-xs text-muted"><?= formatDate($c['created_at'], true) ?></span>
              </div>
              <?php if ($c['user_id'] == Auth::id() || Auth::isAdmin()): ?>
              <button class="btn btn-xs btn-ghost" style="margin-left:auto;color:var(--red)"
                onclick="excluirComentario(<?= $c['id'] ?>, '<?= $modulo ?>', <?= $refId ?>)">✕</button>
              <?php endif; ?>
            </div>
            <div class="comentario-texto"><?= nl2br(htmlspecialchars($c['texto'])) ?></div>
          </div>
        <?php endforeach; endif; ?>
        </div>

        <!-- Formulário -->
        <form class="comentario-form" onsubmit="enviarComentario(event, '<?= $modulo ?>', <?= $refId ?>)">
          <div style="display:flex;gap:8px;align-items:flex-start;margin-top:12px">
            <div class="user-avatar" style="flex-shrink:0"><?= strtoupper(substr(Auth::nome(), 0, 2)) ?></div>
            <div style="flex:1">
              <textarea class="form-textarea" id="novo-comentario-<?= $modulo ?>-<?= $refId ?>"
                placeholder="Escreva um comentário..." rows="2"
                style="margin-bottom:6px;min-height:60px"></textarea>
              <button type="submit" class="btn btn-primary btn-sm">💬 Comentar</button>
            </div>
          </div>
        </form>
      </div>
    </div>

    <style>
    .comentario-item {
      padding: 10px 0;
      border-bottom: 1px solid var(--b1);
    }
    .comentario-item:last-child { border-bottom: none; }
    .comentario-header {
      display: flex; align-items: center; gap: 8px; margin-bottom: 6px;
    }
    .comentario-avatar {
      width: 28px; height: 28px;
      background: linear-gradient(135deg, var(--brand), var(--purple));
      border-radius: 7px; display: flex; align-items: center;
      justify-content: center; font-size: .68rem; font-weight: 700;
      color: #fff; flex-shrink: 0;
    }
    .comentario-autor { font-size: .85rem; color: var(--t0); }
    .comentario-data  { margin-left: 6px; }
    .comentario-texto {
      font-size: .85rem; color: var(--t2);
      line-height: 1.6; padding-left: 36px;
    }
    .comentario-form textarea { font-size: .85rem; }
    </style>

    <script>
    async function enviarComentario(e, modulo, refId) {
      e.preventDefault();
      const ta = document.getElementById('novo-comentario-' + modulo + '-' + refId);
      const texto = ta.value.trim();
      if (!texto) return;
      const r = await api('comentario_criar', {modulo, ref_id: refId, texto});
      if (r.ok) {
        const lista = document.getElementById('comentarios-lista');
        const vazio = lista.querySelector('p.text-muted');
        if (vazio) vazio.remove();
        lista.insertAdjacentHTML('beforeend', r.html);
        ta.value = '';
        document.getElementById('cmt-' + r.id)?.scrollIntoView({behavior:'smooth',block:'nearest'});
      }
    }
    async function excluirComentario(id, modulo, refId) {
      if (!confirm('Excluir este comentário?')) return;
      const r = await api('comentario_excluir', {id});
      if (r.ok) document.getElementById('cmt-' + id)?.remove();
    }
    </script>
    <?php
}
