<?php
// includes/layout.php

function page_start(string $title = '', string $activeMenu = ''): void {
    Auth::require();
    $user     = Auth::user();
    $fullTitle = ($title ? "$title — " : '') . APP_NAME;
    $unread   = Notif::unreadCount();
    $alertas  = alertasVencimento();
    $notifs   = Notif::recent();
    $filialNome = '';
    if ($user['filial_id']) {
        $f = DB::one('SELECT nome FROM filiais WHERE id=?', [$user['filial_id']]);
        $filialNome = $f['nome'] ?? '';
    }

    $menu = [
        ['id'=>'dashboard',  'icon'=>'⊞',  'label'=>'Dashboard',        'href'=>url('/'),                          'perfis'=>['admin','gestor','operador','visualizador']],
        ['id'=>'tarefas',    'icon'=>'✓',  'label'=>'Tarefas',           'href'=>url('/pages/tarefas.php'),         'perfis'=>['admin','gestor','operador']],
        ['id'=>'chamados',   'icon'=>'🎫', 'label'=>'Chamados',          'href'=>url('/pages/chamados.php'),        'perfis'=>['admin','gestor','operador','visualizador']],
        ['id'=>'ativos',     'icon'=>'🖥',  'label'=>'Ativos',            'href'=>url('/pages/ativos.php'),          'perfis'=>['admin','gestor','operador']],
        ['id'=>'fornecedores','icon'=>'🏢','label'=>'Fornecedores',       'href'=>url('/pages/fornecedores.php'),    'perfis'=>['admin','gestor']],
        ['id'=>'financeiro', 'icon'=>'💰', 'label'=>'Financeiro',         'href'=>url('/pages/financeiro.php'),      'perfis'=>['admin','gestor']],
        ['id'=>'contratos',  'icon'=>'📄', 'label'=>'Contratos',          'href'=>url('/pages/contratos.php'),       'perfis'=>['admin','gestor']],
        ['id'=>'processos',  'icon'=>'📋', 'label'=>'Processos Admin.',   'href'=>url('/pages/processos.php'),       'perfis'=>['admin','gestor','operador']],
        ['id'=>'achados',    'icon'=>'🔍', 'label'=>'Achados e Perdidos', 'href'=>url('/pages/achados.php'),         'perfis'=>['admin','gestor','operador']],
        ['id'=>'config',     'icon'=>'⚙',  'label'=>'Configurações',      'href'=>url('/pages/configuracoes.php'),   'perfis'=>['admin']],
    ];
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($fullTitle) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Geist:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body>

<!-- ── TOPBAR ──────────────────────────────────────────────── -->
<header class="topbar">
  <button class="sidebar-toggle" onclick="toggleSidebar()" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>

  <a href="<?= url('/') ?>" class="topbar-brand">
    <div class="brand-mark">GA</div>
    <span class="brand-name">Gestão <span>Admin</span></span>
  </a>

  <div class="topbar-spacer"></div>

  <?php if (!empty($alertas)): ?>
  <div class="topbar-alerts">
    <span class="alert-badge"><?= count($alertas) ?></span>
    <span>⚠</span>
  </div>
  <?php endif; ?>

  <!-- Notifications -->
  <div class="notif-wrapper">
    <button class="topbar-icon-btn" onclick="toggleNotifs()" id="notifBtn">
      🔔
      <?php if ($unread > 0): ?>
      <span class="notif-count"><?= $unread ?></span>
      <?php endif; ?>
    </button>
    <div class="notif-dropdown" id="notifDropdown">
      <div class="notif-header">
        <span>Notificações</span>
        <button onclick="markAllRead()" class="notif-mark-all">Marcar todas</button>
      </div>
      <div id="notifList">
        <?php if (empty($notifs)): ?>
        <div class="notif-empty">Nenhuma notificação</div>
        <?php else: foreach ($notifs as $n): ?>
        <div class="notif-item <?= $n['lida'] ? '' : 'unread' ?>" data-id="<?= $n['id'] ?>">
          <div class="notif-icon notif-<?= $n['tipo'] ?>">
            <?= match($n['tipo']) { 'aviso'=>'⚠️','alerta'=>'🚨','sucesso'=>'✅', default=>'ℹ️' } ?>
          </div>
          <div class="notif-body">
            <div class="notif-title"><?= htmlspecialchars($n['titulo']) ?></div>
            <div class="notif-msg"><?= htmlspecialchars($n['mensagem']) ?></div>
            <div class="notif-time"><?= formatDate($n['created_at'], true) ?></div>
          </div>
        </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>

  <!-- User menu -->
  <div class="user-menu-wrapper">
    <button class="user-btn" onclick="toggleUserMenu()">
      <div class="user-avatar"><?= strtoupper(substr($user['nome'], 0, 2)) ?></div>
      <div class="user-info">
        <span class="user-name"><?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?></span>
        <span class="user-role"><?= ucfirst($user['perfil']) ?></span>
      </div>
      <span class="user-chevron">▾</span>
    </button>
    <div class="user-dropdown" id="userDropdown">
      <div class="user-dropdown-header">
        <strong><?= htmlspecialchars($user['nome']) ?></strong>
        <span><?= htmlspecialchars($user['email']) ?></span>
        <?php if ($filialNome): ?><span class="user-filial">📍 <?= htmlspecialchars($filialNome) ?></span><?php endif; ?>
      </div>
      <a href="<?= url('/pages/perfil.php') ?>" class="user-dropdown-item">👤 Meu Perfil</a>
      <a href="<?= url('/logout.php') ?>" class="user-dropdown-item user-logout">⏻ Sair</a>
    </div>
  </div>
</header>

<!-- ── SIDEBAR ──────────────────────────────────────────────── -->
<aside class="sidebar" id="sidebar">
  <nav class="sidebar-nav">
    <?php foreach ($menu as $item):
      if (!in_array(Auth::perfil(), $item['perfis'])) continue;
      $isActive = $activeMenu === $item['id'];
    ?>
    <a href="<?= $item['href'] ?>"
       class="nav-item <?= $isActive ? 'nav-active' : '' ?>"
       title="<?= $item['label'] ?>">
      <span class="nav-icon"><?= $item['icon'] ?></span>
      <span class="nav-label"><?= $item['label'] ?></span>
      <?php if ($item['id'] === 'chamados'):
        $open = DB::count('chamados', "status='aberto'");
        if ($open > 0): ?>
        <span class="nav-badge"><?= $open ?></span>
      <?php endif; endif; ?>
    </a>
    <?php endforeach; ?>
  </nav>

  <div class="sidebar-footer">
    <div class="sidebar-version">v<?= APP_VERSION ?></div>
  </div>
</aside>

<!-- ── OVERLAY ──────────────────────────────────────────────── -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<!-- ── ALERTAS DE VENCIMENTO ──────────────────────────────── -->
<?php if (!empty($alertas)): ?>
<div class="alertas-bar">
  <?php foreach (array_slice($alertas, 0, 3) as $a): ?>
  <a href="<?= $a['link'] ?>" class="alerta-item alerta-<?= $a['tipo'] ?>">
    <?= $a['icon'] ?> <?= htmlspecialchars($a['msg']) ?>
  </a>
  <?php endforeach; ?>
  <?php if (count($alertas) > 3): ?>
  <span class="alerta-more">+<?= count($alertas) - 3 ?> mais</span>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- ── MAIN ──────────────────────────────────────────────────── -->
<main class="main-content" id="mainContent">
<?php
}

function page_end(): void { ?>
</main>

<script src="<?= asset('js/app.js') ?>"></script>
<script>
const APP_BASE = <?= json_encode(APP_BASE) ?>;
</script>
</body>
</html>
<?php }

// ── Page sub-components ───────────────────────────────────────
function pageHeader(string $title, string $subtitle = '', array $actions = []): void { ?>
<div class="page-header">
  <div class="page-header-left">
    <h1 class="page-title"><?= htmlspecialchars($title) ?></h1>
    <?php if ($subtitle): ?>
    <p class="page-subtitle"><?= htmlspecialchars($subtitle) ?></p>
    <?php endif; ?>
  </div>
  <?php if (!empty($actions)): ?>
  <div class="page-header-actions">
    <?php foreach ($actions as $a): ?>
    <a href="<?= $a['href'] ?? '#' ?>"
       onclick="<?= $a['onclick'] ?? '' ?>"
       class="btn <?= $a['cls'] ?? 'btn-primary' ?>">
      <?= $a['icon'] ?? '' ?> <?= $a['label'] ?>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php }

function flashMessage(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        echo "<div class=\"flash flash-{$f['type']}\">{$f['msg']}</div>";
    }
}

function setFlash(string $msg, string $type = 'success'): void {
    Auth::start();
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function statCard(string $label, mixed $value, string $icon, string $color = 'blue', string $sub = '', string $href = ''): void {
    $tag = $href ? 'a' : 'div';
    $attr = $href ? "href=\"$href\"" : '';
    echo "<$tag class=\"stat-card stat-$color\" $attr>
      <div class=\"stat-icon\">$icon</div>
      <div class=\"stat-body\">
        <div class=\"stat-value\">$value</div>
        <div class=\"stat-label\">$label</div>
        " . ($sub ? "<div class=\"stat-sub\">$sub</div>" : '') . "
      </div>
    </$tag>";
}
