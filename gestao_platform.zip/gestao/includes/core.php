<?php
// includes/core.php

// ── DB ────────────────────────────────────────────────────────
class DB {
    private static ?PDO $pdo = null;

    public static function get(): PDO {
        if (self::$pdo === null) {
            $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
            try {
                self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                http_response_code(500);
                die('<div style="font-family:monospace;background:#0d0d0d;color:#e8e8e8;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;font-size:1rem">
                <div style="background:#161616;border:1px solid #e85d4a;border-radius:10px;padding:2rem;max-width:480px;text-align:center">
                <div style="font-size:2rem;margin-bottom:1rem">⚠️</div>
                <h2 style="color:#e85d4a;margin-bottom:.75rem">Erro de Conexão</h2>
                <p style="color:#a8a8a8">Não foi possível conectar ao MySQL.<br>Verifique <code style="color:#fbbf24">includes/config.php</code></p>
                <p style="color:#555;font-size:.8rem;margin-top:1rem">' . htmlspecialchars($e->getMessage()) . '</p>
                </div></div>');
            }
        }
        return self::$pdo;
    }

    public static function run(string $sql, array $p = []): PDOStatement {
        $stmt = self::get()->prepare($sql);
        $stmt->execute($p);
        return $stmt;
    }

    public static function one(string $sql, array $p = []): ?array {
        return self::run($sql, $p)->fetch() ?: null;
    }

    public static function all(string $sql, array $p = []): array {
        return self::run($sql, $p)->fetchAll();
    }

    public static function insert(string $sql, array $p = []): int {
        self::run($sql, $p);
        return (int) self::get()->lastInsertId();
    }

    public static function count(string $table, string $where = '1', array $p = []): int {
        $r = self::one("SELECT COUNT(*) as c FROM `$table` WHERE $where", $p);
        return (int)($r['c'] ?? 0);
    }
}

// ── Auth ──────────────────────────────────────────────────────
class Auth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params(['lifetime'=>SESSION_LIFETIME,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
            session_start();
        }
    }

    public static function user(): ?array {
        self::start();
        return $_SESSION['gestao_user'] ?? null;
    }

    public static function id(): ?int    { return self::user()['id'] ?? null; }
    public static function nome(): string { return self::user()['nome'] ?? ''; }
    public static function perfil(): string { return self::user()['perfil'] ?? 'visualizador'; }
    public static function isAdmin(): bool  { return self::perfil() === 'admin'; }
    public static function isGestor(): bool { return in_array(self::perfil(), ['admin','gestor']); }

    public static function require(): void {
        if (!self::id()) { header('Location: ' . url('/login.php')); exit; }
    }

    public static function requireAdmin(): void {
        self::require();
        if (!self::isAdmin()) { header('Location: ' . url('/')); exit; }
    }

    public static function can(string $modulo, string $acao = 'ver'): bool {
        if (self::isAdmin()) return true;
        $r = DB::one(
            'SELECT id FROM permissoes WHERE user_id=? AND modulo=? AND acao=?',
            [self::id(), $modulo, $acao]
        );
        return (bool)$r;
    }

    public static function login(string $username, string $password): bool {
        $user = DB::one('SELECT * FROM users WHERE (username=? OR email=?) AND ativo=1', [$username, $username]);
        if ($user && password_verify($password, $user['password'])) {
            self::start();
            $_SESSION['gestao_user'] = [
                'id'     => $user['id'],
                'nome'   => $user['nome'],
                'email'  => $user['email'],
                'perfil' => $user['perfil'],
                'filial_id' => $user['filial_id'],
            ];
            DB::run('UPDATE users SET ultimo_acesso=NOW() WHERE id=?', [$user['id']]);
            Log::write('auth', 'login', 'Login realizado');
            return true;
        }
        return false;
    }

    public static function register(string $nome, string $username, string $email, string $password, string $perfil = 'operador'): bool {
        if (DB::one('SELECT id FROM users WHERE username=? OR email=?', [$username, $email])) return false;
        DB::insert(
            'INSERT INTO users (nome,username,email,password,perfil) VALUES (?,?,?,?,?)',
            [$nome, $username, $email, password_hash($password, PASSWORD_BCRYPT), $perfil]
        );
        return true;
    }

    public static function logout(): void {
        Log::write('auth', 'logout', 'Logout realizado');
        self::start();
        session_destroy();
        header('Location: ' . url('/login.php'));
        exit;
    }
}

// ── Log de atividades ─────────────────────────────────────────
class Log {
    public static function write(string $modulo, string $acao, string $detalhes = ''): void {
        $uid = Auth::id();
        $ip  = $_SERVER['REMOTE_ADDR'] ?? '';
        DB::run(
            'INSERT INTO activity_log (user_id, modulo, acao, detalhes, ip) VALUES (?,?,?,?,?)',
            [$uid, $modulo, $acao, $detalhes, $ip]
        );
    }
}

// ── Notificações ──────────────────────────────────────────────
class Notif {
    public static function create(int $userId, string $titulo, string $msg, string $tipo = 'info', string $modulo = '', int $refId = 0): void {
        DB::run(
            'INSERT INTO notificacoes (user_id,titulo,mensagem,tipo,modulo,ref_id) VALUES (?,?,?,?,?,?)',
            [$userId, $titulo, $msg, $tipo, $modulo, $refId]
        );
    }

    public static function unreadCount(): int {
        $uid = Auth::id();
        if (!$uid) return 0;
        return DB::count('notificacoes', 'user_id=? AND lida=0', [$uid]);
    }

    public static function recent(int $limit = 8): array {
        $uid = Auth::id();
        if (!$uid) return [];
        return DB::all(
            'SELECT * FROM notificacoes WHERE user_id=? ORDER BY created_at DESC LIMIT ?',
            [$uid, $limit]
        );
    }

    public static function markRead(int $id): void {
        DB::run('UPDATE notificacoes SET lida=1 WHERE id=? AND user_id=?', [$id, Auth::id()]);
    }

    public static function markAllRead(): void {
        DB::run('UPDATE notificacoes SET lida=1 WHERE user_id=?', [Auth::id()]);
    }
}

// ── Helpers gerais ────────────────────────────────────────────
function statusBadge(string $status, array $map = []): string {
    $defaults = [
        'ativo'        => ['label'=>'Ativo',         'cls'=>'badge-green'],
        'inativo'      => ['label'=>'Inativo',        'cls'=>'badge-gray'],
        'pendente'     => ['label'=>'Pendente',        'cls'=>'badge-yellow'],
        'aberto'       => ['label'=>'Aberto',          'cls'=>'badge-blue'],
        'em_andamento' => ['label'=>'Em Andamento',    'cls'=>'badge-blue'],
        'em_atendimento'=>['label'=>'Em Atendimento',  'cls'=>'badge-blue'],
        'resolvido'    => ['label'=>'Resolvido',        'cls'=>'badge-green'],
        'fechado'      => ['label'=>'Fechado',          'cls'=>'badge-gray'],
        'concluida'    => ['label'=>'Concluída',        'cls'=>'badge-green'],
        'concluido'    => ['label'=>'Concluído',        'cls'=>'badge-green'],
        'cancelada'    => ['label'=>'Cancelada',        'cls'=>'badge-gray'],
        'cancelado'    => ['label'=>'Cancelado',        'cls'=>'badge-gray'],
        'pago'         => ['label'=>'Pago',             'cls'=>'badge-green'],
        'paga'         => ['label'=>'Pago',             'cls'=>'badge-green'],
        'aprovada'     => ['label'=>'Aprovada',         'cls'=>'badge-green'],
        'rejeitada'    => ['label'=>'Rejeitada',        'cls'=>'badge-red'],
        'vencido'      => ['label'=>'Vencido',          'cls'=>'badge-red'],
        'vencida'      => ['label'=>'Vencido',          'cls'=>'badge-red'],
        'vencendo'     => ['label'=>'Vencendo',         'cls'=>'badge-yellow'],
        'alta'         => ['label'=>'Alta',             'cls'=>'badge-orange'],
        'critica'      => ['label'=>'Crítica',          'cls'=>'badge-red'],
        'urgente'      => ['label'=>'Urgente',          'cls'=>'badge-red'],
        'baixa'        => ['label'=>'Baixa',            'cls'=>'badge-gray'],
        'media'        => ['label'=>'Média',            'cls'=>'badge-blue'],
        'guardado'     => ['label'=>'Guardado',         'cls'=>'badge-blue'],
        'entregue'     => ['label'=>'Entregue',         'cls'=>'badge-green'],
        'doado'        => ['label'=>'Doado',            'cls'=>'badge-purple'],
        'enviado_caju' => ['label'=>'Enviado Caju-RJ',  'cls'=>'badge-purple'],
    ];
    $all = array_merge($defaults, $map);
    $info = $all[$status] ?? ['label' => ucfirst(str_replace('_',' ',$status)), 'cls' => 'badge-gray'];
    return "<span class=\"badge {$info['cls']}\">{$info['label']}</span>";
}

function prioridadeIcon(string $p): string {
    return match($p) {
        'urgente' => '🔴',
        'alta'    => '🟠',
        'media'   => '🟡',
        'baixa'   => '🟢',
        'critica' => '🚨',
        default   => '⚪',
    };
}

function formatMoney(float $v): string {
    return 'R$ ' . number_format($v, 2, ',', '.');
}

function formatDate(string $d, bool $time = false): string {
    if (!$d || $d === '0000-00-00') return '—';
    $fmt = $time ? 'd/m/Y H:i' : 'd/m/Y';
    return date($fmt, strtotime($d));
}

function diasRestantes(string $data): int {
    return (int)ceil((strtotime($data) - time()) / 86400);
}

function gerarNumero(string $prefixo, string $tabela, string $campo = 'numero'): string {
    $count = DB::count($tabela, '1') + 1;
    return $prefixo . '-' . date('Y') . '-' . str_pad($count, 5, '0', STR_PAD_LEFT);
}

function sanitize(string $v): string {
    return htmlspecialchars(strip_tags(trim($v)), ENT_QUOTES);
}

function filiais(): array {
    return DB::all('SELECT id, nome FROM filiais WHERE ativa=1 ORDER BY nome');
}

function users(): array {
    return DB::all('SELECT id, nome FROM users WHERE ativo=1 ORDER BY nome');
}

function fornecedores(): array {
    return DB::all("SELECT id, razao_social FROM fornecedores WHERE status='ativo' ORDER BY razao_social");
}

function selectOptions(array $items, string $valField, string $labelField, mixed $selected = null, string $placeholder = 'Selecione...'): string {
    $html = "<option value=''>$placeholder</option>";
    foreach ($items as $item) {
        $sel = ($item[$valField] == $selected) ? 'selected' : '';
        $html .= "<option value='{$item[$valField]}' $sel>" . htmlspecialchars($item[$labelField]) . "</option>";
    }
    return $html;
}

function alertasVencimento(): array {
    $alertas = [];
    $hoje = date('Y-m-d');
    $em30  = date('Y-m-d', strtotime('+30 days'));

    // Contratos vencendo
    $contratos = DB::all(
        "SELECT id, titulo, data_fim FROM contratos
         WHERE status='ativo' AND data_fim BETWEEN ? AND ?",
        [$hoje, $em30]
    );
    foreach ($contratos as $c) {
        $dias = diasRestantes($c['data_fim']);
        $alertas[] = ['tipo'=>'contrato','icon'=>'📄','msg'=>"Contrato \"{$c['titulo']}\" vence em $dias dia(s)",'link'=>url('/pages/contratos.php')];
    }

    // Processos vencendo
    $processos = DB::all(
        "SELECT id, titulo, data_prazo FROM processos
         WHERE status='em_andamento' AND data_prazo BETWEEN ? AND ?",
        [$hoje, $em30]
    );
    foreach ($processos as $p) {
        $dias = diasRestantes($p['data_prazo']);
        $alertas[] = ['tipo'=>'processo','icon'=>'📋','msg'=>"Processo \"{$p['titulo']}\" vence em $dias dia(s)",'link'=>url('/pages/processos.php')];
    }

    // Chamados SLA vencendo (próximas 4 horas)
    $sla = DB::all(
        "SELECT id, numero, titulo FROM chamados
         WHERE status IN ('aberto','em_atendimento') AND prazo_sla < DATE_ADD(NOW(), INTERVAL 4 HOUR)"
    );
    foreach ($sla as $s) {
        $alertas[] = ['tipo'=>'sla','icon'=>'🚨','msg'=>"Chamado {$s['numero']} com SLA crítico",'link'=>url('/pages/chamados.php')];
    }

    return $alertas;
}

// ── Comentários (universal) ───────────────────────────────────
class Comentario {
    public static function listar(string $modulo, int $refId): array {
        return DB::all(
            "SELECT c.*, u.nome as autor FROM comentarios c
             LEFT JOIN users u ON c.user_id = u.id
             WHERE c.modulo = ? AND c.ref_id = ?
             ORDER BY c.created_at ASC",
            [$modulo, $refId]
        );
    }

    public static function salvar(string $modulo, int $refId, string $texto): void {
        DB::run(
            "INSERT INTO comentarios (modulo, ref_id, user_id, texto) VALUES (?,?,?,?)",
            [$modulo, $refId, Auth::id(), trim($texto)]
        );
    }

    public static function excluir(int $id): void {
        DB::run("DELETE FROM comentarios WHERE id = ? AND user_id = ?", [$id, Auth::id()]);
    }

    public static function count(string $modulo, int $refId): int {
        return DB::count('comentarios', 'modulo=? AND ref_id=?', [$modulo, $refId]);
    }
}

// ── Histórico de edições ──────────────────────────────────────
class HistoricoEdicao {
    public static function registrar(string $modulo, int $refId, array $antes, array $depois, array $campos): void {
        foreach ($campos as $campo) {
            $va = $antes[$campo] ?? '';
            $vd = $depois[$campo] ?? '';
            if ((string)$va !== (string)$vd) {
                DB::run(
                    "INSERT INTO historico_edicoes (modulo,ref_id,user_id,campo,valor_antes,valor_depois)
                     VALUES (?,?,?,?,?,?)",
                    [$modulo, $refId, Auth::id(), $campo, $va, $vd]
                );
            }
        }
    }

    public static function listar(string $modulo, int $refId): array {
        return DB::all(
            "SELECT h.*, u.nome FROM historico_edicoes h
             LEFT JOIN users u ON h.user_id = u.id
             WHERE h.modulo=? AND h.ref_id=?
             ORDER BY h.created_at DESC",
            [$modulo, $refId]
        );
    }
}

// ── Renderizar seção de comentários ──────────────────────────
function renderComentarios(string $modulo, int $refId): void {
    $comentarios = Comentario::listar($modulo, $refId);
    ?>
    <div class="card mt-2" id="comentarios-section">
      <div class="card-header">
        <span class="card-title">💬 Comentários <span class="badge badge-gray"><?= count($comentarios) ?></span></span>
      </div>
      <div class="card-body" style="padding-bottom:0">
        <?php if (empty($comentarios)): ?>
          <p style="color:var(--t3);font-size:.88rem;margin-bottom:16px">Nenhum comentário ainda.</p>
        <?php else: foreach ($comentarios as $c): ?>
          <div class="comentario-item" id="coment-<?= $c['id'] ?>">
            <div class="comentario-header">
              <div class="comentario-avatar"><?= strtoupper(substr($c['autor'] ?? 'U', 0, 2)) ?></div>
              <div>
                <span class="comentario-autor"><?= htmlspecialchars($c['autor'] ?? 'Usuário') ?></span>
                <span class="comentario-data"><?= formatDate($c['created_at'], true) ?></span>
              </div>
              <?php if ($c['user_id'] == Auth::id() || Auth::isAdmin()): ?>
              <form method="POST" style="margin-left:auto">
                <input type="hidden" name="_action" value="excluir_comentario">
                <input type="hidden" name="comentario_id" value="<?= $c['id'] ?>">
                <button class="btn btn-xs btn-ghost" style="color:var(--red)"
                  onclick="return confirm('Excluir comentário?')" title="Excluir">✕</button>
              </form>
              <?php endif; ?>
            </div>
            <div class="comentario-texto"><?= nl2br(htmlspecialchars($c['texto'])) ?></div>
          </div>
        <?php endforeach; endif; ?>
      </div>
      <form method="POST" class="comentario-form">
        <input type="hidden" name="_action" value="comentar">
        <textarea name="comentario" class="form-textarea" rows="2"
          placeholder="Escreva um comentário..." required
          style="border-radius:0;border-left:none;border-right:none;border-bottom:none;resize:none"></textarea>
        <div style="padding:10px 18px;background:var(--bg-3);border-top:1px solid var(--b1);display:flex;justify-content:flex-end">
          <button type="submit" class="btn btn-primary btn-sm">💬 Comentar</button>
        </div>
      </form>
    </div>

    <style>
    .comentario-item { padding:14px 18px; border-bottom:1px solid var(--b1); }
    .comentario-item:last-child { border-bottom:none; }
    .comentario-header { display:flex; align-items:center; gap:10px; margin-bottom:8px; }
    .comentario-avatar { width:30px; height:30px; border-radius:8px; background:linear-gradient(135deg,var(--brand),var(--purple)); display:flex; align-items:center; justify-content:center; font-size:.7rem; font-weight:700; color:#fff; flex-shrink:0; }
    .comentario-autor { font-size:.85rem; font-weight:600; color:var(--t0); }
    .comentario-data  { font-size:.72rem; color:var(--t3); margin-left:8px; font-family:var(--ff-mono); }
    .comentario-texto { font-size:.88rem; color:var(--t2); line-height:1.6; }
    .comentario-form  { border-top:1px solid var(--b1); }
    </style>
    <?php
}
